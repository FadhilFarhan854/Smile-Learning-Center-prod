

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    
    <!-- Page Heading -->
    <div class="d-flex justify-content-start mb-4">
        <h1 class="h3 mb-2 text-gray-800">Data User</h1><button class="btn btn-info ml-3" id="print"><i class="fa fa-print"></i> Print</button>
        <a href="<?php echo e(url('export-user')); ?>" class="btn btn-success ml-3"><i class="fa fa-download"></i> Export</a>
    </div>
    <?php if(session('status')): ?>
    <div class="alert alert-success">
        <?php echo e(session('status')); ?>

    </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
    <?php endif; ?>
    <!-- DataTales Example --> 
    <div class="card shadow mb-4" id="print-this">
        <div class="card-header py-3">
            <?php if(auth()->user()->role != 'administrator 2'): ?>
            <a href="<?php echo e(route('user.create')); ?>" class="btn btn-success">Tambah User</a>
            <?php endif; ?>
            
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>NIK</th>
                            <th>No. Rekening</th>
                            <th>Tanggal Masuk</th>
                            <?php if(auth()->user()->role != 'administrator 2'): ?>
                            <th>Action</th>
                            <?php endif; ?>
                            
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>NIK</th>
                            <th>No. Rekening</th>
                            <th>Tanggal Masuk</th>
                            <?php if(auth()->user()->role != 'administrator 2'): ?>
                            <th>Action</th>
                            <?php endif; ?>
                        </tr> 
                    </tfoot>
                    <tbody>
                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->name); ?></td>
                            <td><?php echo e($item->email); ?></td>
                            <td><?php echo e(ucwords($item->role)); ?></td>
                            <td><?php echo e($item->nik); ?></td>
                            <td><?php echo e($item->rekening); ?></td>
                            <td><?php echo e(formattedDate($item->tanggal_masuk)); ?></td>
                            <?php if(auth()->user()->role != 'administrator 2'): ?>
                            <td>
                                <div class="d-flex justify-content-start">
                                    <a href="<?php echo e(route('user.edit', $item->id)); ?>" class="btn btn-info">Edit</a>
                                    <form class="ml-3" action="<?php echo e(route('user.destroy', $item->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button class="btn btn-danger" onclick="return confirm('Yakin Hapus Data?')">Hapus</button>
                                    </form>
                                </div>
                            </td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
</div>
<!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $('#change-guru').on('change', function () {
        var userConfirm = confirm('Yakin ganti item?');
        
        if (userConfirm) {
            var id = $(this).data('id');
            var guru = $(this).val();
            var csrfToken ="<?php echo e(csrf_token()); ?>";
            
            $.ajax({
                url: 'change-guru',
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN' : csrfToken
                },
                data: {
                    id:id,
                    guru:guru
                },
                success: function (response) {
                    $('#guru-' + response.id).html('<span>'+response.guru+'</span>');
                },
                error: function (error) {
                    console.error(error);
                }
            })
        }
        
    })
</script>
<script>
    $('#change-admin').on('change', function () {
        var confirmUser = confirm('Yakin ganti item?');

        if (confirmUser) {
            var id = $(this).data('id');
            var admin = $(this).val();
            var csrfToken = '<?php echo e(csrf_token()); ?>'

            $.ajax({
                url:'change-admin',
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN' : csrfToken
                },
                data: {
                    id:id,
                    admin:admin
                },
                success: function(response) {
                    $('#admin-' + response.id).html('<span>' + response.admin + '</span>');
                },
                error: function (error) {
                    console.error(error);
                }
            })
        }
    })
</script>
<script src="<?php echo e(asset('printThis-master/printThis.js')); ?>"></script>
<script>
    $('#print').on('click', function() {
        $("#print-this").printThis();
    })
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/edakarya.com/bimbel.edakarya.com/resources/views/user/index.blade.php ENDPATH**/ ?>