<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
    <thead>
        <tr>
			<th>Nama Guru</th>
            <th>NIM</th>
            <th>Nama</th>
            <th>TTL</th>
            <th>Nama Ayah</th>
        <th>Nama Ibu</th>
            <th>No HP</th>
            <th>Tgl Masuk</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
				<td>
                    <span class="<?php echo e(optional($item->kelas->guru)->status === 'non-aktif' ? 'text-danger' : ''); ?>">
                        <?php echo e(optional($item->kelas->guru)->name ?? '--'); ?>

                    </span> / 
                    <span class="<?php echo e(optional($item->kelas->user)->status === 'non-aktif' ? 'text-danger' : ''); ?>">
                        <?php echo e(optional($item->kelas->user)->name ?? '--'); ?>

                    </span>
                </td>
                <td><?php echo e($item->nim); ?></td>
                <td><a href="<?php echo e(route('siswa.show', $item->id)); ?>"><?php echo e($item->nama); ?></a></td>
                <td><?php echo e($item->tempat_lahir); ?>, <?php echo e($item->tanggal_lahir); ?></td>
				<td><?php echo e($item->nama_ayah); ?></td>
				<td><?php echo e($item->nama_ibu); ?></td>
				<td><?php echo e($item->no_wali_1); ?></td>
				<td><?php echo e($item->tanggal_masuk); ?></td>        
                <td>          
                    <span><?php echo e(ucwords($item->status)); ?></span>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table><?php /**PATH /var/www/vhosts/edakarya.com/bimbel.edakarya.com/resources/views/exports/siswa.blade.php ENDPATH**/ ?>