<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
    <thead>
        <tr>
            <th>Nama</th>
            <th>Email</th>
            <th>Role</th>
            <th>NIK</th>
            <th>No. Rekening</th>
            <th>Tanggal Masuk</th>
    
            
        </tr>
    </thead>
    <tfoot>
        <tr>
            <th>Nama</th>
            <th>Email</th>
            <th>Role</th>
            <th>NIK</th>
            <th>No. Rekening</th>
            <th>Tanggal Masuk</th>

        </tr> 
    </tfoot>
    <tbody>
        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item->name); ?></td>
            <td><?php echo e($item->email); ?></td>
            <td><?php echo e(ucwords($item->role)); ?></td>
            <td><?php echo e($item->nik); ?></td>
            <td><?php echo e($item->rekening); ?></td>
            <td><?php echo e(formattedDate($item->tanggal_masuk)); ?></td>

        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\M. Rivaldi Anwar Putra\bimbel1501\resources\views/exports/user.blade.php ENDPATH**/ ?>