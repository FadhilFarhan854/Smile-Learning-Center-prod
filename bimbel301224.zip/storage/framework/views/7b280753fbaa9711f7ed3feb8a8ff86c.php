

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    
    <!-- Page Heading -->
    <div class="d-flex justify-content-start">
        <h1 class="h3 mb-2 text-gray-800">Order </h1>
        <?php if(auth()->user()->role != 'administrator 2' && auth()->user()->role != 'admin' && auth()->user()->role != 'motivator' && auth()->user()->role != 'guru'): ?>
        <button class="btn btn-info ml-3" id="print"><i class="fa fa-print"></i> Print</button>
        <a href="<?php echo e(url('export-order/'.$month.'/'.$year)); ?>" class="btn btn-success ml-3"><i class="fa fa-download"></i> Export</a>
        <?php endif; ?>
    </div>
    
    <?php if(session('status')): ?>
    <div class="alert alert-success">
        <?php echo e(session('status')); ?>

    </div>
    <?php endif; ?>
    
    <?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
    <?php endif; ?>
    <!-- DataTales Example -->
    
    <div class="card shadow mb-4" id="print-this">
        <div class="card-header py-3">
            <div class="row">
                <div class="d-flex justify-content-around col-lg-8">
                    <?php for($i = 1; $i <= 12; $i++): ?>
                    <form action="<?php echo e(route('order.index')); ?>" method="get">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('get'); ?>
                        <input type="hidden" name="month" value="<?php echo e($i); ?>">
                        <input type="hidden" name="tahun" value="<?php echo e($year); ?>">
                        <button type="submit" class="btn btn-light <?php echo e($month == $i ? 'active' : ''); ?>"><?php echo e($months[$i]); ?></button>
                    </form>
                    <?php endfor; ?>
                </div>
                <div class="col-lg-4 d-flex justify-content-between">
                    <select name="tahun" id="change-tahun" class="form-control mr-4" data-month="<?php echo e($month); ?>">
                        <?php for($i = $year+1; $i > $year-4; $i--): ?>
                        <option value="<?php echo e($i); ?>" <?php echo e($year == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                        <?php endfor; ?>
                    </select>
                    <?php if(auth()->user()->role != 'administrator 2' && auth()->user()->role != 'admin' && auth()->user()->role != 'guru'): ?>
                    <a id="rekap-toggle" class="text-success text-center"><i class="fa fa-2x fa-list-alt"></i><br>Rekap</a>
                    <?php endif; ?>
                </div>
            </div>
		<div class="row">
			<div class="col-lg-8 d-flex justify-content-start ml-3">
                    <a data-toggle="modal" class="siswa-total">Total : <?php echo e($siswasi); ?></a>
				<a data-toggle="modal" class="siswa-aktif ml-3">Aktif : <?php echo e($aktif->count()); ?></a>
				<a data-toggle="modal" class="siswa-cuti ml-3">Cuti : <?php echo e($cuti->count()); ?></a>
				<a data-toggle="modal" class="siswa-keluar ml-3">Keluar : <?php echo e($keluar->count()); ?></a>
				<a data-toggle="modal" class="siswa-belum ml-3">Blm Konfirmasi : <?php echo e($siswasi - $aktif->count() - $cuti->count() - $keluar->count()); ?></a>
                </div>
		</div>
        </div>
        <div class="card-body" >
			<div class="row justify-content-end mb-3">
			<div class="col-lg-5 d-flex justify-content-end ml-3">
				<form action="<?php echo e(route('order.index')); ?>" method="get">
    <?php echo csrf_field(); ?>
    <?php echo method_field('get'); ?>
    <div style="display: flex;">
		<label>Cari Siswa (Global): </label>
        <input type="text" name="search" class="form-control" id="global-search" style="flex: 1;">
        <button type="submit" class="btn btn-primary ml-2">Go!</button>
    </div>
    <input type="hidden" name="month" value="<?php echo e($month); ?>">
    <input type="hidden" name="tahun" value="<?php echo e($year); ?>">
					<div class="d-flex mt-2">
                    <label class="mt-2">Unit:</label>
                    <select name="unit" id="change-unit" class="form-control ml-2"  form="unit-form">
                        <option value="">All</option>
                        <?php $__currentLoopData = $unit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ut): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($ut->id); ?>" <?php echo e($reqUnit == $ut->id ? 'selected' : ''); ?>><?php echo e($ut->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <input type="hidden" name="month" value="<?php echo e($month); ?>" form="unit-form">
                    <input type="hidden" name="tahun" value="<?php echo e($year); ?>" form="unit-form">
                    <input type="hidden" name="kelas" value="<?php echo e($reqKelas); ?>" form="unit-form">
                    <label class="mt-2 ml-3">Kelas:</label>
                    <select name="kelas" id="change-kelas" class="form-control ml-2"  form="kelas-form">
                        <option value="">All</option>
                        <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($kl->id); ?>" <?php echo e($reqKelas == $kl->id ? 'selected' : ''); ?>><?php echo e($kl->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <input type="hidden" name="month" value="<?php echo e($month); ?>" form="kelas-form">
                    <input type="hidden" name="tahun" value="<?php echo e($year); ?>" form="kelas-form">
                    <input type="hidden" name="unit" value="<?php echo e($reqUnit); ?>" form="kelas-form">
                </div>
</form>

                  
                </div>
		</div>
			
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Kelas</th>
							<th>NIM</th>
                            <th>Siswa</th>
                            <th>Status</th>
                            <th>SPP</th>
                            <th>Pembayaran</th>
                            <th>Level</th>
                            <th>Baca</th>
                            <th>Tulis</th>
                            <th>Hitung</th>
                            <th>Modul SD</th>
                            <th>English</th>
                            <th>Iqro</th>
                            <th>Pendaftaran Set</th>
                            <th>Modul Lain</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						
                        <tr>
							<form class="ml-3" action="<?php echo e(route('order.store')); ?>" method="post" id="order-form-<?php echo e($item->id); ?>">
    <?php echo csrf_field(); ?>
                            <td><?php echo e($item->kelas->nama); ?></td>
							<td><?php echo e($item->nim); ?></td>
                            <td><?php echo e($item->nama); ?></td>
                            <td>
                                <?php if(optional($item->checkSPP($month, $year))->verified == 'yes'): ?>
                                <span class="<?php echo e($item->checkStatus($item->checkSPP($month, $year)->status)); ?>"><?php echo e(ucwords($item->checkSPP($month, $year)->status)); ?></span>
                                <?php else: ?>
                                <span >Menunggu konfirmasi</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(auth()->user()->role != 'administrator 2'): ?>             

                                <?php if(count($item->spp->where('bulan', $month)->where('tahun', $year)) > 0 && $item->checkSPP($month, $year)->verified == 'yes'): ?>
                                <span><?php echo e($item->spp->where('bulan', $month)->where('tahun', $year)->first()->tanggal != null ? formattedDate($item->spp->where('bulan', $month)->where('tahun', $year)->first()->tanggal) : ''); ?></span><?php echo $item->checkSPP($month, $year)->tanggal != null ? '<br>' : ''; ?>

                                <span class="cnfrmd">Sudah diverifikasi</span>
                                <?php elseif(count($item->spp->where('bulan', $month)->where('tahun', $year)) > 0 && $item->checkSPP($month, $year)->verified == 'no'): ?>
                                <span><?php echo e($item->spp->where('bulan', $month)->where('tahun', $year)->first()->tanggal != null ? formattedDate($item->spp->where('bulan', $month)->where('tahun', $year)->first()->tanggal).' : ' : ''); ?><?php echo e(ucwords($item->checkSPP($month, $year)->status)); ?> <a class="input-pembayaran" data-id="<?php echo e($item->id); ?>" data-nama="<?php echo e($item->nama); ?>"><i class="fa fa-pen" style="cursor: pointer"></i></a></span><br>
                                <a data-toggle="modal" data-target="pay-confirm-modal-<?php echo e($item->id); ?>" data-id="<?php echo e(optional($item->checkSPP($month, $year))->id); ?>" data-nama="<?php echo e($item->nama); ?>" class="pay-cnfrm pay-confirm">Klik Untuk Verifikasi</a>
                                <?php elseif(count($item->spp->where('bulan', $month)->where('tahun', $year)) <= 0): ?>
                                <a class="purple-cnfrm input-pembayaran" data-id="<?php echo e($item->id); ?>" data-nama="<?php echo e($item->nama); ?>"><i class="fa fa-plus"></i> Pembayaran </a>
                                <?php endif; ?>

                                <?php else: ?>

                                <?php if(count($item->spp->where('bulan', $month)->where('tahun', $year)) > 0 && $item->checkSPP($month, $year)->verified == 'yes'): ?>
                                <span><?php echo e($item->spp->where('bulan', $month)->where('tahun', $year)->first()->tanggal != null ? formattedDate($item->spp->where('bulan', $month)->where('tahun', $year)->first()->tanggal) : ''); ?></span>
                                <?php else: ?>
                                <span class="text-danger">Belum dikonfirmasi</span>
                                <?php endif; ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(auth()->user()->role != 'administrator 2'): ?>             

                                <?php if(count($item->additional->where('bulan', $month)->where('tahun', $year)) > 0 ): ?>
                                <?php echo e($item->additional->where('bulan', $month)->where('tahun', $year)->first()->status); ?> : IDR <?php echo e(number_format($item->additional->where('bulan', $month)->where('tahun', $year)->first()->biaya)); ?> <a data-toggle="modal" data-target="insert-note-<?php echo e($item->id); ?>" data-id="<?php echo e($item->id); ?>" data-nama="<?php echo e($item->nama); ?>" class="insert-note"><i class="fa fa-pen"></i></a>
                                <?php else: ?>
                                <a data-toggle="modal" data-target="insert-note-<?php echo e($item->id); ?>" data-id="<?php echo e($item->id); ?>" data-nama="<?php echo e($item->nama); ?>" class="insert-note"><i class="fa fa-plus"></i> Pembayaran</a>
                                <?php endif; ?>

                                <?php else: ?>

                                <?php if(count($item->additional->where('bulan', $month)->where('tahun', $year))): ?>
                                <span><?php echo e($item->additional->where('bulan', $month)->where('tahun', $year)->first()->status); ?></span>
                                <?php else: ?>
                                <span class="text-danger">Belum dikonfirmasi</span>
                                <?php endif; ?>

                                <?php endif; ?>
                            </td>
                            <td class="td-min">
                                <?php if($item->checkOrder($month, $year)): ?>
                                <?php echo e($item->checkOrder($month, $year)->level); ?>

                                <?php else: ?>
								<?php if(auth()->user()->role != 'administrator 2'): ?>  
								<select name="level" id="change-level-<?php echo e($item->id); ?>" class="form-control change-level" data-id="<?php echo e($item->id); ?>" form="order-form-<?php echo e($item->id); ?>">
                                    <option value="" <?php echo e($item->level != null ? 'disabled' : ''); ?>>N/A</option>
                                    <?php for($i = 1; $i < 10; $i++): ?>
                                    <option value="<?php echo e($i); ?>"  <?php echo e($item->level == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                                    <?php endfor; ?>
                                </select>
								<?php else: ?>
                                <select name="level" id="change-level-<?php echo e($item->id); ?>" class="form-control change-level" data-id="<?php echo e($item->id); ?>" form="order-form-<?php echo e($item->id); ?>">
                                    <option value="" <?php echo e($item->level != null ? 'disabled' : ''); ?>>N/A</option>
                                    <?php for($i = 1; $i < 10; $i++): ?>
                                    <option value="<?php echo e($i); ?>" <?php echo e($i < $item->level ? 'disabled' : ''); ?> <?php echo e($item->level == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                                    <?php endfor; ?>
                                </select>
								<?php endif; ?>
                                <?php endif; ?>
                            </td>
                            <td class="td-min">
                                <?php if($item->checkOrderSpec($month, $year, 'baca')): ?>
                                <?php echo e($item->checkOrderSpec($month, $year, 'baca')->modul->nama ?? '--'); ?>

                                <?php else: ?>
                                <select name="modul_baca" id="" class="form-control" form="order-form-<?php echo e($item->id); ?>">
                                    <option value="">--</option>
                                    <?php $__currentLoopData = $item->chooseModul('baca'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>">Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if(session('error-baca-'.$item->id)): ?>
                                <div class="alert alert-danger p-1">
                                    <?php echo e(session('error-baca-'.$item->id)); ?>

                                </div>
                                <?php endif; ?>
                                <?php endif; ?>
                            </td>
                            <td class="td-min">
                                <?php if($item->checkOrderSpec($month, $year, 'tulis')): ?>
                                <?php echo e($item->checkOrderSpec($month, $year, 'tulis')->modul->nama ?? '--'); ?>

                                <?php else: ?>
                                <select name="modul_tulis" id="" class="form-control" form="order-form-<?php echo e($item->id); ?>">
                                    <option value="">--</option>
                                    <?php $__currentLoopData = $item->chooseModulAll('tulis'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>">Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if(session('error-tulis-'.$item->id)): ?>
                                <div class="alert alert-danger p-1">
                                    <?php echo e(session('error-tulis-'.$item->id)); ?>

                                </div>
                                <?php endif; ?>
                                <?php endif; ?>
                                
                            </td>
                            <td class="td-min">
                                <?php if($item->checkOrderSpec($month, $year, 'hitung')): ?>
                                <?php echo e($item->checkOrderSpec($month, $year, 'hitung')->modul->nama ?? '--'); ?>

                                <?php else: ?>
                                <select name="modul_hitung" id="" class="form-control" form="order-form-<?php echo e($item->id); ?>">
                                    <option value="">--</option>
                                    <?php $__currentLoopData = $item->chooseModulAll('hitung'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>">Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if(session('error-hitung-'.$item->id)): ?>
                                <div class="alert alert-danger p-1">
                                    <?php echo e(session('error-hitung-'.$item->id)); ?>

                                </div>
                                <?php endif; ?>
                                <?php endif; ?>
                            </td>
                            <td class="td-min">
                                <?php if($item->checkOrderSpec($month, $year, 'modul SD')): ?>
                                <?php echo e($item->checkOrderSpec($month, $year, 'modul SD')->modul->nama ?? '--'); ?>

                                <?php else: ?>
                                <select name="modul_sd" id="" class="form-control" form="order-form-<?php echo e($item->id); ?>">
                                    <option value="">--</option>
                                    <?php $__currentLoopData = $item->chooseModulAll('modul SD'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>">Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if(session('error-sd-'.$item->id)): ?>
                                <div class="alert alert-danger p-1">
                                    <?php echo e(session('error-sd-'.$item->id)); ?>

                                </div>
                                <?php endif; ?>
                                <?php endif; ?>
                            </td>
                            <td class="td-min">
                                <?php if($item->checkOrderSpec($month, $year, 'english')): ?>
                                <?php echo e($item->checkOrderSpec($month, $year, 'english')->modul->nama ?? '--'); ?>

                                <?php else: ?>
                                <select name="english" id="" class="form-control" form="order-form-<?php echo e($item->id); ?>">
                                    <option value="">--</option>
                                    <?php $__currentLoopData = $item->chooseModulAll('english'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>">Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if(session('error-english-'.$item->id)): ?>
                                <div class="alert alert-danger p-1">
                                    <?php echo e(session('error-english-'.$item->id)); ?>

                                </div>
                                <?php endif; ?>
                                <?php endif; ?>
                            </td>
                            <td class="td-min">
                                <?php if($item->checkOrderSpec($month, $year, 'iqro')): ?>
                                <?php echo e($item->checkOrderSpec($month, $year, 'iqro')->modul->nama ?? '--'); ?>

                                <?php else: ?>
                                <select name="iqro" id="" class="form-control" form="order-form-<?php echo e($item->id); ?>">
                                    <option value="">--</option>
                                    <?php $__currentLoopData = $item->chooseModulAll('iqro'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>">Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if(session('error-iqro-'.$item->id)): ?>
                                <div class="alert alert-danger p-1">
                                    <?php echo e(session('error-iqro-'.$item->id)); ?>

                                </div>
                                <?php endif; ?>
                                <?php endif; ?>
                            </td>
                            <td class="td-min">
                                <?php if($item->checkOrderSpec($month, $year, 'daftar')): ?>
                                <?php echo e($item->checkOrderSpec($month, $year, 'daftar')->modul->nama ?? '--'); ?>

                                <?php else: ?>
                                <select name="daftar" id="" class="form-control" form="order-form-<?php echo e($item->id); ?>">
                                    <option value="">--</option>
                                    <?php $__currentLoopData = $item->chooseModulAll('daftar'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>">Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if(session('error-daftar-'.$item->id)): ?>
                                <div class="alert alert-danger p-1">
                                    <?php echo e(session('error-daftar-'.$item->id)); ?>

                                </div>
                                <?php endif; ?>
                                <?php endif; ?>
                            </td>
                            <td class="td-min">
                                <?php if($item->checkOrderSpec($month, $year, 'lain')): ?>
                                <?php echo e($item->checkOrderSpec($month, $year, 'lain')->modul->nama ?? '--'); ?>

                                <?php else: ?>
                                <select name="lain" id="" class="form-control" form="order-form-<?php echo e($item->id); ?>">
                                    <option value="">--</option>
                                    <?php $__currentLoopData = $item->chooseModulAll('lain'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>">Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if(session('error-lain-'.$item->id)): ?>
                                <div class="alert alert-danger p-1">
                                    <?php echo e(session('error-lain-'.$item->id)); ?>

                                </div>
                                <?php endif; ?>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(auth()->user()->role != 'administrator 2'): ?>
                                <div class="d-flex justify-content-start">
                                    <input type="hidden" name="month" value="<?php echo e($month); ?>" form="order-form-<?php echo e($item->id); ?>">
                                    <input type="hidden" name="tahun" value="<?php echo e($year); ?>" form="order-form-<?php echo e($item->id); ?>">
                                    <input type="hidden" name="siswa" value="<?php echo e($item->id); ?>" form="order-form-<?php echo e($item->id); ?>">
                                    <input type="hidden" name="status" value="<?php echo e($item->status); ?>" form="order-form-<?php echo e($item->id); ?>">
                                    <?php if($item->checkOrder($month, $year)): ?>
                                    <span>Sudah di Submit</span> 
                                    <?php if(auth()->user()->role != 'admin' && auth()->user()->role != 'motivator'): ?>
                                    <a href="<?php echo e(url('order/edit/'.$item->id.'/'.$month.'/'.$year)); ?>" class="btn btn-info ml-3">Edit</a>
                                    <?php endif; ?>
                                    
                                    <?php elseif(!$item->checkSPP($month, $year) || $item->checkSPP($month, $year)->verified == 'no'): ?>
                                    <span class="not-cnfrmd">Pembayaran Belum disetujui Administrator</span>
                                    <?php elseif($item->checkSPP($month, $year)->status == 'keluar'): ?>
                                    <span class="text-danger">Siswa Keluar</span>
                                    <?php else: ?>
                                    <button class="btn btn-warning"  type="submit" form="order-form-<?php echo e($item->id); ?>">Submit</button>
                                    <?php endif; ?>
                                </div>
                                <?php else: ?>
                                <div class="d-flex justify-content-start">
                                    <?php if($item->checkOrder($month, $year)): ?>
                                    <span>Sudah di Submit</span> 
                                    <?php elseif(!$item->checkSPP($month, $year) || $item->checkSPP($month, $year)->verified == 'no'): ?>
                                    <span class="text-danger">Pembayaran Belum disetujui Administrator</span>
                                    <?php elseif($item->checkSPP($month, $year)->status == 'keluar'): ?>
                                    <span class="text-danger">Siswa Keluar</span>
                                    <?php else: ?>
                                    <span>Belum disubmit</span>
                                    <?php endif; ?>
                                </div>
                                <?php endif; ?>
                            </td>
						</form>
                        </tr>
			

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
			
			<?php echo e($siswa->appends(request()->except('page'))->links()); ?>

                    </tbody>
                </table>

            </div>
        </div>
    </div>
</div>



<!-- Pay confirm Modal -->
<div class="modal fade" id="pay-confirm-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Modal Title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(url('konfirmasi-spp')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="form-group">
                        <label class="required">Konfirmasi Pembayaran</label>
                        <select name="status"  class="form-control">
                            <option value="">-- PILIH STATUS --</option>
                            <option value="yes">Pembayaran Sudah Masuk dan Terverifikasi</option>
                            <option value="no">Pembayaran Belum Terkonfirmasi</option>
                        </select>
                    </div>
                    <input type="hidden" name="id" id="id-siswa-pay-confirm">
                    <input type="hidden" name="month" value="<?php echo e($month); ?>">
                    <input type="hidden" name="tahun" value="<?php echo e($year); ?>">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary">Konfirmasi</button>
                </div>
            </form>
        </div>
    </div>
</div>   
<!-- /Pay confirm Modal -->

<!-- Input Pembayaran Modal -->
<div class="modal fade" id="input-pembayaran-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Modal Title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(url('input-spp')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="form-group">
                        <label class="required">Status Siswa</label>
                        <select name="status"  class="form-control">
                            <option value="">-- PILIH STATUS --</option>
                            <option value="aktif">Aktif</option>
                            <option value="cuti">Cuti</option>
                            <option value="keluar">Keluar</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label >Tanggal Pembayaran</label>
                        <input type="date" name="tanggal" class="form-control">
                        <span>Kosongkan apabila siswa keluar</span>
                    </div>
                    <input type="hidden" name="id" id="id-siswa-input-pembayaran">
                    <input type="hidden" name="month" value="<?php echo e($month); ?>">
                    <input type="hidden" name="tahun" value="<?php echo e($year); ?>">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary">Konfirmasi</button>
                </div>
            </form>
        </div>
    </div>
</div>   
<!-- /Input Pembayaran Modal -->
<!-- Insert Note Modal -->
<div class="modal fade" id="insert-note" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="insert-note-title" id="exampleModalLabel">Modal Title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(url('insert-additional')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="form-group">
                        <label class="required">Biaya </label>
                        <input type="number" name="biaya" required class="form-control">
                    </div>
                    <div class="form-group">
                        <label class="required">Tambah Note </label>
                        <textarea name="status" id="" cols="70" class="form-control" rows="5"></textarea>
                    </div>
                    <input type="hidden" name="id" id="id-siswa-insert-note" >
                    <input type="hidden" name="month" value="<?php echo e($month); ?>">
                    <input type="hidden" name="tahun" value="<?php echo e($year); ?>">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary">Konfirmasi</button>
                </div>
            </form>
        </div>
    </div>
</div>   
<!-- /Insert Note Modal -->


<div class="modal fade " id="rekap-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Rekap Order <?php echo e($month); ?>-<?php echo e($year); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <table class="table table-bordered" id="rekap-modul">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Modul</th>
                            <th>Permintaan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $orderCounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($item->modul->nama ?? '--'); ?></td>
                            <td><?php echo e($item->count); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </tbody>
                </table>
                <table class="table table-bordered d-none" id="rekap-unit">
                    <thead>
                        <tr>
                            <th>Unit</th>
                            <th>Kelas</th>
                            <th>Kategori</th>
							<th>Modul</th>
                            <th>Jumlah</th>
							<th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $prevUnit = null;
                        $prevKelas = null;
						$prevKat = null;
						$prevMod = null;
                        $unitRowspan = 0;
                        ?>
                        
                        <?php $__currentLoopData = $ordersByUnit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unitName => $ordersByKelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <?php $__currentLoopData = $ordersByKelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelasName => $ordersByKat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php $__currentLoopData = $ordersByKat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat => $modul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

						<?php $__currentLoopData = $modul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mod_id => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td <?php echo $unitName === $prevUnit ? "style='border-top:solid 2px #fff'" : ''; ?>><b><?php echo e($unitName !== $prevUnit ? $unitName : ''); ?></b></td>
							<td <?php echo $unitName.$kelasName === $prevKelas ? "style='border-top:solid 2px #fff'" : ''; ?>><b><?php echo e($unitName.$kelasName !== $prevKelas ? $kelasName : ''); ?></b></td>
                           
							<td <?php echo $unitName.$kelasName.$kat === $prevKat ? "style='border-top:solid 2px #fff'" : ''; ?>><b><?php echo e($unitName.$kelasName.$kat !== $prevKat ? $kat : ''); ?></b></td>
                            
							<td><?php echo e($moduls->where('id', $mod_id)->first()->nama ?? '-- '); ?></td>
                            <td><?php echo e($count); ?></td>
							
                            <td <?php echo $unitName.$kelasName.$kat === $prevKat ? "style='border-top:solid 2px #fff'" : ''; ?>><b><?php echo e($unitName.$kelasName.$kat !== $prevKat ? $modul->sum() : ''); ?></b></td>
                      
                        </tr>
                        
                        <?php
                        $prevUnit = $unitName;
                        $prevKelas = $unitName.$kelasName;
						$prevKat = $unitName.$kelasName.$kat;
						$prevMod = $unitName.$kelasName.$kat.$mod_id;
                        ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    
                </table>
            </div>
            <div class="modal-footer">
				<button class="btn btn-warning" id="print2">Print</button>
                <button class="btn btn-primary" id="button-rekap-modul">Unit View</button>
                <button class="btn btn-primary d-none" id="button-rekap-unit">Modul View</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>   
<!-- /.container-fluid -->

<!-- Form Change Unit -->
<form class="ml-3" action="<?php echo e(route('order.index')); ?>" method="get" id="unit-form">
    <?php echo csrf_field(); ?>
</form>
<!-- /Form Change Unit -->
<!-- Form Change Kelas -->
<form class="ml-3" action="<?php echo e(route('order.index')); ?>" method="get" id="kelas-form">
    <?php echo csrf_field(); ?>
</form>
<!-- /Form Change Unit -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $('#change-tahun').on('change', function () {
        var tahun = $(this).val();
        var month = $(this).data('month');
        var csrfToken = "<?php echo e(csrf_token()); ?>"
        
        $.ajax({
            url: "<?php echo e(route('order.index')); ?>",
            method: 'GET',
            headers: {
                'X-CSRF-TOKEN': csrfToken
            },
            data: {
                tahun: tahun,
                month: month // Make sure the key matches the controller's parameter
            },
            dataType: 'html', // Expect HTML response
            success: function(response) {
                // Update the entire HTML of the document
                document.open();
                document.write(response);
                document.close();
                
                var newUrl = window.location.pathname + '?tahun=' + tahun + '&month=' + month;
                window.history.pushState({}, '', newUrl);
            },
            error: function (error) {
                console.log(error);
            }
        });
        
    })
</script>
<script>
    $('.insert-note').on('click', function () {
        var id = $(this).data('id');
        var nama = $(this).data('nama');
        
        $('.insert-note-title').text('Tambah Note - '+nama);
        $('#id-siswa-insert-note').val(id);
        $('#insert-note').modal('show');
    });
</script>

<script>
    $('.change-level').on('change', function() {
        var userConfirmed = confirm('Yakin Ganti Level?');
        
        if (userConfirmed) {
            var id = $(this).data('id');
            var level = $(this).val();
            var csrfToken = "<?php echo e(csrf_token()); ?>";
            
            $.ajax({
                url:'change-level',
                method:'POST',
                headers:{
                    'X-CSRF-TOKEN':csrfToken
                },
                data:{
                    id:id,
                    level:level
                },
                success: function(response){
                    console.log(response);
                },
                error: function(error){
                    console.log(error);
                }
            })
        }
    })
</script>

<script>
    $('#rekap-toggle').on('click', function(){
        $('#rekap-modal').modal('show');
    })
</script>

<script>
    $('#button-rekap-modul').on('click', function(){
        $('#button-rekap-modul').addClass('d-none');
        $('#button-rekap-unit').removeClass('d-none');
        $('#rekap-unit').removeClass('d-none');
        $('#rekap-modul').addClass('d-none');
    })
    
    $('#button-rekap-unit').on('click', function(){
        $('#button-rekap-unit').addClass('d-none');
        $('#button-rekap-modul').removeClass('d-none');
        $('#rekap-modul').removeClass('d-none');
        $('#rekap-unit').addClass('d-none');
    })
</script>

<script>
    $('.pay-confirm').on('click', function () {
        var id = $(this).data('id');
        var nama = $(this).data('nama');
        console.log(id);
        $('.modal-title').text('Verifikasi Pembayaran - '+nama);
        $('#id-siswa-pay-confirm').val(id);
        $('#pay-confirm-modal').modal('show');
    });
</script>

<script>
    $('.input-pembayaran').on('click', function () {
        var id = $(this).data('id');
        var nama = $(this).data('nama');
        
        $('.modal-title').text('Input Tanggal Pembayaran - '+nama);
        $('#id-siswa-input-pembayaran').val(id);
        $('#input-pembayaran-modal').modal('show');
    });
</script>
<script src="<?php echo e(asset('printThis-master/printThis.js')); ?>"></script>
<script>
    $('#print').on('click', function() {
        $("#print-this").printThis();
    })
	
	$('#print2').on('click', function() {
        $("#rekap-unit").printThis();
    })
	
	$(document).ready(function() {
    // Check if the body has the specific-page class
    if ($('body').hasClass('pagination')) {
        // Hide the DataTables information element
        $('.pagination').css('display', 'none');
    }
});
    
</script>

<script>
    $('#change-unit').on('change', function() {
        $('#unit-form').submit();
    });

    $('#change-kelas').on('change', function() {
        $('#kelas-form').submit();
    })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/exakarya.com/bimbel.exakarya.com/resources/views/order/index.blade.php ENDPATH**/ ?>