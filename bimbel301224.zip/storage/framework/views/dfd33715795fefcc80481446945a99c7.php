<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
    <thead>
        <tr>
            <th>Unit</th>
            <th>Nama</th>
            <th>Admin</th>
            <th>Guru</th>
            <th>Jumlah Siswa</th>
       
        </tr>
    </thead>

    <tbody>
        <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item->unit->nama); ?></td>
            <td><?php echo e($item->nama); ?></td>
            <td id="admin-<?php echo e($item->id); ?>">
   
                <span class="<?php echo e(isset($item->user->status) && $item->user->status === 'non-aktif' ? 'text-danger' : ''); ?>"><?php echo e($item->user->name ?? '--'); ?></span>
              
            </td>
            <td id="guru-<?php echo e($item->id); ?>">

                <span class="<?php echo e(isset($item->guru->status) && $item->guru->status === 'non-aktif' ? 'text-danger' : ''); ?>"><?php echo e($item->guru->name ?? '--'); ?></span>
               
            </td>
            <td><?php echo e($item->jumlahSiswa()); ?></td>

        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\M. Rivaldi Anwar Putra\bimbel1501\resources\views/exports/kelas.blade.php ENDPATH**/ ?>