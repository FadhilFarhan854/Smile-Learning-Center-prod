

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    
    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Edit Order</h1>
    
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="col-lg-6 offset-lg-2">
                <form action="<?php echo e(route('order.update', $order->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <div class="form-group">
                        <label class="required">Level</label>
						<?php if(auth()->user()->role != 'administrator 2'): ?>     
						<select name="level" required class="form-control">
                            <option value="">-- PILIH --</option>
                            <?php for($i = 1; $i < 10; $i++): ?>
                            <option value="<?php echo e($i); ?>" <?php echo e($order->level == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                            <?php endfor; ?>
                        </select>
						<?php else: ?>
                        <select name="level" required class="form-control">
                            <option value="">-- PILIH --</option>
                            <?php for($i = 1; $i < 10; $i++): ?>
                            <option value="<?php echo e($i); ?>" <?php echo e($i < $order->level ? 'disabled' : ''); ?> <?php echo e($order->level == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                            <?php endfor; ?>
                        </select>
						<?php endif; ?>
                    </div>
                    
                    <div class="form-group">
                        <label >Modul Baca</label>
                        <select class="form-control" id="modul-baca">
                            <option value="">--</option>
                            <?php $__currentLoopData = $order->siswa->chooseModul('baca'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>" <?php echo e($baca->modul_id == $md->id ? 'selected' : ''); ?>>Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="hidden" name="modul_baca" id="input-baca" value="<?php echo e(null); ?>">
                        <?php if(session('error-baca-'.$order->siswa_id)): ?>
                        <div class="alert alert-danger p-1">
                            <?php echo e(session('error-baca-'.$order->siswa_id)); ?>

                        </div>
                        <?php endif; ?>
                    </div>
                    
                    
                    <div class="form-group">
                        <label >Modul Tulis</label>
                        <select  class="form-control" id="modul-tulis">
                            <option value="">--</option>
                            <?php $__currentLoopData = $order->siswa->chooseModulAll('tulis'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>" <?php echo e($tulis->modul_id == $md->id ? 'selected' : ''); ?>>Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="hidden" name="modul_tulis" id="input-tulis" value="<?php echo e(null); ?>">
                        <?php if(session('error-tulis-'.$order->siswa_id)): ?>
                        <div class="alert alert-danger p-1">
                            <?php echo e(session('error-tulis-'.$order->siswa_id)); ?>

                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group">
                        <label>Modul Hitung</label>
                        <select class="form-control" id="modul-hitung">
                            <option value="">--</option>
                            <?php $__currentLoopData = $order->siswa->chooseModulAll('hitung'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>" <?php echo e($hitung->modul_id == $md->id ? 'selected' : ''); ?>>Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="hidden" name="modul_hitung" id="input-hitung" value="<?php echo e(null); ?>">
                        <?php if(session('error-hitung-'.$order->siswa_id)): ?>
                        <div class="alert alert-danger p-1">
                            <?php echo e(session('error-hitung-'.$order->siswa_id)); ?>

                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group">
                        <label >Modul SD</label>
                        <select class="form-control" id="modul-sd">
                            <option value="">--</option>
                            <?php $__currentLoopData = $order->siswa->chooseModulAll('modul SD'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>" <?php echo e($modul_sd->modul_id == $md->id ? 'selected' : ''); ?>>Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="hidden" name="modul_sd" id="input-sd" value="<?php echo e(null); ?>">
                        <?php if(session('error-sd-'.$order->siswa_id)): ?>
                        <div class="alert alert-danger p-1">
                            <?php echo e(session('error-sd-'.$order->siswa_id)); ?>

                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group">
                        <label >Modul English</label>
                        <select class="form-control" id="modul-english">
                            <option value="">--</option>
                            <?php $__currentLoopData = $order->siswa->chooseModulAll('english'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>" <?php echo e($english->modul_id == $md->id ? 'selected' : ''); ?>>Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="hidden" name="english" id="input-english" value="<?php echo e(null); ?>">
                        <?php if(session('error-english-'.$order->siswa_id)): ?>
                        <div class="alert alert-danger p-1">
                            <?php echo e(session('error-english-'.$order->siswa_id)); ?>

                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group">
                        <label>Iqro</label>
                        <select class="form-control" id="modul-iqro">
                            <option value="">--</option>
                            <?php $__currentLoopData = $order->siswa->chooseModulAll('iqro'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>" <?php echo e($iqro->modul_id == $md->id ? 'selected' : ''); ?>>Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="hidden" name="iqro" id="input-iqro" value="<?php echo e(null); ?>">
                        <?php if(session('error-iqro-'.$order->siswa_id)): ?>
                        <div class="alert alert-danger p-1">
                            <?php echo e(session('error-iqro-'.$order->siswa_id)); ?>

                        </div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label>Daftar</label>
                        <select class="form-control" id="modul-daftar">
                            <option value="">--</option>
                            <?php $__currentLoopData = $order->siswa->chooseModulAll('daftar'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>" <?php echo e($daftar?->modul_id == $md->id ? 'selected' : ''); ?>>Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="hidden" name="daftar" id="input-daftar" value="<?php echo e(null); ?>">
                        <?php if(session('error-daftar-'.$order->siswa_id)): ?>
                        <div class="alert alert-danger p-1">
                            <?php echo e(session('error-daftar-'.$order->siswa_id)); ?>

                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group">
                        <label >Modul Lain</label>
                        <select class="form-control" id="modul-lain">
                            <option value="">--</option>
                            <?php $__currentLoopData = $order->siswa->chooseModulAll('lain'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>" <?php echo e($lain->modul_id == $md->id ? 'selected' : ''); ?>>Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="hidden" name="lain" id="input-lain" value="<?php echo e(null); ?>">
                        <?php if(session('error-lain-'.$order->siswa_id)): ?>
                        <div class="alert alert-danger p-1">
                            <?php echo e(session('error-lain-'.$order->siswa_id)); ?>

                        </div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label >English Verbal</label>
                        <select class="form-control" id="modul-verbal">
                            <option value="">--</option>
                            <?php $__currentLoopData = $order->siswa->chooseModulAll('verbal'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>" <?php echo e($verbal->modul_id == $md->id ? 'selected' : ''); ?>>Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="hidden" name="verbal" id="input-verbal" value="<?php echo e(null); ?>">
                        <?php if(session('error-verbal-'.$order->siswa_id)): ?>
                        <div class="alert alert-danger p-1">
                            <?php echo e(session('error-verbal-'.$order->siswa_id)); ?>

                        </div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label >Sempoa</label>
                        <select class="form-control" id="modul-sempoa">
                            <option value="">--</option>
                            <?php $__currentLoopData = $order->siswa->chooseModulAll('sempoa'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>" <?php echo e($sempoa->modul_id == $md->id ? 'selected' : ''); ?>>Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="hidden" name="sempoa" id="input-sempoa" value="<?php echo e(null); ?>">
                        <?php if(session('error-sempoa-'.$order->siswa_id)): ?>
                        <div class="alert alert-danger p-1">
                            <?php echo e(session('error-sempoa-'.$order->siswa_id)); ?>

                        </div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label >IQ</label>
                        <select class="form-control" id="modul-iq">
                            <option value="">--</option>
                            <?php $__currentLoopData = $order->siswa->chooseModulAll('iq'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>" <?php echo e($iq->modul_id == $md->id ? 'selected' : ''); ?>>Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="hidden" name="iq" id="input-iq" value="<?php echo e(null); ?>">
                        <?php if(session('error-iq-'.$order->siswa_id)): ?>
                        <div class="alert alert-danger p-1">
                            <?php echo e(session('error-iq-'.$order->siswa_id)); ?>

                        </div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label >Aritmatika</label>
                        <select class="form-control" id="modul-aritmatika">
                            <option value="">--</option>
                            <?php $__currentLoopData = $order->siswa->chooseModulAll('aritmatika'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>" <?php echo e($aritmatika->modul_id == $md->id ? 'selected' : ''); ?>>Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="hidden" name="aritmatika" id="input-aritmatika" value="<?php echo e(null); ?>">
                        <?php if(session('error-aritmatika-'.$order->siswa_id)): ?>
                        <div class="alert alert-danger p-1">
                            <?php echo e(session('error-aritmatika-'.$order->siswa_id)); ?>

                        </div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label >Juara</label>
                        <select class="form-control" id="modul-juara">
                            <option value="">--</option>
                            <?php $__currentLoopData = $order->siswa->chooseModulAll('juara'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>" <?php echo e($juara->modul_id == $md->id ? 'selected' : ''); ?>>Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="hidden" name="juara" id="input-juara" value="<?php echo e(null); ?>">
                        <?php if(session('error-juara-'.$order->siswa_id)): ?>
                        <div class="alert alert-danger p-1">
                            <?php echo e(session('error-juara-'.$order->siswa_id)); ?>

                        </div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label >Ortu</label>
                        <select class="form-control" id="modul-ortu">
                            <option value="">--</option>
                            <?php $__currentLoopData = $order->siswa->chooseModulAll('ortu'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>" <?php echo e($ortu->modul_id == $md->id ? 'selected' : ''); ?>>Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="hidden" name="ortu" id="input-ortu" value="<?php echo e(null); ?>">
                        <?php if(session('error-ortu-'.$order->siswa_id)): ?>
                        <div class="alert alert-danger p-1">
                            <?php echo e(session('error-ortu-'.$order->siswa_id)); ?>

                        </div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label >Cryon</label>
                        <select class="form-control" id="modul-cryon">
                            <option value="">--</option>
                            <?php $__currentLoopData = $order->siswa->chooseModulAll('cryon'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>" <?php echo e($cryon->modul_id == $md->id ? 'selected' : ''); ?>>Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="hidden" name="cryon" id="input-cryon" value="<?php echo e(null); ?>">
                        <?php if(session('error-cryon-'.$order->siswa_id)): ?>
                        <div class="alert alert-danger p-1">
                            <?php echo e(session('error-cryon-'.$order->siswa_id)); ?>

                        </div>
                        <?php endif; ?>
                    </div>
                    <input type="hidden" name="siswa" value="<?php echo e($order->siswa_id); ?>">
                    <input type="hidden" name="month" value="<?php echo e($order->bulan); ?>">
                    <input type="hidden" name="tahun" value="<?php echo e($order->tahun); ?>">
                    <input type="hidden" name="status" value="<?php echo e($order->status); ?>">
                    <div class="form-group">
                        <button class="btn btn-success" type="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
</div>
<!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $('#modul-baca').on('change', function(){
            var modul = $(this).val();

            $('#input-baca').val(modul);
        });

        $('#modul-tulis').on('change', function(){
            var modul = $(this).val();

            $('#input-tulis').val(modul);
        });

        $('#modul-hitung').on('change', function(){
            var modul = $(this).val();

            $('#input-hitung').val(modul);
        });

        $('#modul-sd').on('change', function(){
            var modul = $(this).val();

            $('#input-sd').val(modul);
        });

        $('#modul-english').on('change', function(){
            var modul = $(this).val();

            $('#input-english').val(modul);
        });

        $('#modul-iqro').on('change', function(){
            var modul = $(this).val();

            $('#input-iqro').val(modul);
        });

        $('#modul-daftar').on('change', function(){
            var modul = $(this).val();

            $('#input-daftar').val(modul);
        });

        $('#modul-lain').on('change', function(){
            var modul = $(this).val();

            $('#input-lain').val(modul);
        });

        $('#modul-verbal').on('change', function(){
            var modul = $(this).val();

            $('#input-verbal').val(modul);
        });

        $('#modul-sempoa').on('change', function(){
            var modul = $(this).val();

            $('#input-sempoa').val(modul);
        });

        $('#modul-iq').on('change', function(){
            var modul = $(this).val();

            $('#input-iq').val(modul);
        });

        $('#modul-aritmatika').on('change', function(){
            var modul = $(this).val();

            $('#input-aritmatika').val(modul);
        });

        $('#modul-juara').on('change', function(){
            var modul = $(this).val();

            $('#input-juara').val(modul);
        });

        $('#modul-ortu').on('change', function(){
            var modul = $(this).val();

            $('#input-ortu').val(modul);
        });

        $('#modul-cryon').on('change', function(){
            var modul = $(this).val();

            $('#input-cryon').val(modul);
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/edakarya.com/bimbel.edakarya.com/resources/views/order/edit.blade.php ENDPATH**/ ?>