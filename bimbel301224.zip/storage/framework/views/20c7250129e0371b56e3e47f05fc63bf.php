

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    
    <!-- Page Heading -->
    <div class="d-flex justify-content-start mb-4">
        <h1 class="h3 mb-2 text-gray-800">Data Siswa</h1>
        <?php if(auth()->user()->role != 'administrator 2' && auth()->user()->role != 'admin' && auth()->user()->role != 'motivator' && auth()->user()->role != 'guru'): ?>
        <button class="btn btn-info ml-3" id="print"><i class="fa fa-print"></i> Print</button>
        <a class="btn btn-success ml-3 import"><i class="fa fa-upload"></i> Import</a>
        <a href="<?php echo e(url('export-siswa')); ?>" class="btn btn-success ml-3"><i class="fa fa-download"></i> Export</a>
        <?php endif; ?>
    </div>
    <?php if(session('status')): ?>
    <div class="alert alert-success">
        <?php echo e(session('status')); ?>

    </div>
    <?php endif; ?>
    
    <!-- DataTales Example -->
    <div class="card shadow mb-4" id="print-this">
        <div class="card-header py-3">
            <?php if(auth()->user()->role != 'administrator 2'): ?>
            <a href="<?php echo e(route('siswa.create')); ?>" class="btn btn-success">Tambah Siswa</a>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>NIM</th>
                            <th>Nama</th>
                            <th>Kelas</th>
                            <th>Guru/Admin</th>
                           
                            <th>Tgl Masuk</th>
                            <th class="td-min">Lvl</th>
                            
                                <th>Status</th>
                                <th>Keterangan</th>
                                <?php if(auth()->user()->role != 'administrator 2'): ?>
                                <th>Action</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->nim); ?></td>
                                <td><a href="<?php echo e(route('siswa.show', $item->id)); ?>"><?php echo e($item->nama); ?></a></td>
                                <td><?php echo e($item->kelas->nama); ?></td>
                                <td>
                                    <span class="<?php echo e(optional($item->kelas->guru)->status === 'non-aktif' ? 'text-danger' : ''); ?>">
                                        <?php echo e(optional($item->kelas->guru)->name ?? '--'); ?>

                                    </span> / 
                                    <span class="<?php echo e(optional($item->kelas->user)->status === 'non-aktif' ? 'text-danger' : ''); ?>">
                                        <?php echo e(optional($item->kelas->user)->name ?? '--'); ?>

                                    </span>
                                </td>
                                
                              
                                <td><?php echo e(formattedDate($item->tanggal_masuk)); ?></td>
                                <td>
                                    <?php if(auth()->user()->role != 'administrator 2' && auth()->user()->role != 'admin' && auth()->user()->role != 'guru'): ?>
                                    <select name="level" id="change-level-<?php echo e($item->id); ?>" class="form-control" data-id="<?php echo e($item->id); ?>">
                                        <option value="" <?php echo e($item->level != null ? 'disabled' : ''); ?>>N/A</option>
                                        <?php for($i = 1; $i < 10; $i++): ?>
                                        <option value="<?php echo e($i); ?>" <?php echo e($i < $item->level ? 'disabled' : ''); ?> <?php echo e($item->level == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                    <?php else: ?>
                                    <span><?php echo e($item->level ?? 'N/A'); ?></span>
                                    <?php endif; ?>
                                </td>
                                
                                <td>
                                   
                                    <?php if(auth()->user()->role != 'administrator 2' ): ?>

                                    <select name="status" data-id="<?php echo e($item->id); ?>" class="form-control change-status select-special">
                                        <option value="">-- PILIH --</option>
                                        <option value="baru" >Baru</option>
                                        <option value="aktif" <?php echo e($item->status == 'aktif' ? 'selected' : ''); ?>>Aktif</option>
                                        <option value="cuti" <?php echo e($item->status == 'cuti' ? 'selected' : ''); ?>>Cuti</option>
                                        <option value="keluar" <?php echo e($item->status == 'keluar' ? 'selected' : ''); ?>>Keluar</option>
                                        <option value="lulus" <?php echo e($item->status == 'lulus' ? 'selected' : ''); ?>>Lulus</option>
                                    </select>
                               
                                    <?php else: ?>
                                    <span><?php echo e(ucwords($item->status)); ?></span>
                                    <?php endif; ?>

                                </td>
                                <td>
                                    <?php if(auth()->user()->role != 'administrator 2' && auth()->user()->role != 'admin' && auth()->user()->role != 'guru'): ?>
                                    <?php if($item->keterangan == null): ?>
                                    <a data-toggle="modal" data-target="insert-note-<?php echo e($item->id); ?>" data-id="<?php echo e($item->id); ?>" data-nama="<?php echo e($item->nama); ?>" class="insert-note"><i class="fa fa-plus"></i> Note</a>
                                    <?php else: ?>
                                    <?php echo e($item->keterangan); ?> <a data-toggle="modal" data-target="insert-note-<?php echo e($item->id); ?>" data-id="<?php echo e($item->id); ?>" data-nama="<?php echo e($item->nama); ?>" class="insert-note"><i class="fa fa-pen"></i></a>
                                    <?php endif; ?>
                                    <?php else: ?>
                                    <span><?php echo e($item->keterangan); ?></span>
                                    <?php endif; ?>
                                </td>
                                <?php if(auth()->user()->role != 'administrator 2'): ?>
                                <td>
                                    <div class="d-flex justify-content-start">
                                        <a href="<?php echo e(route('siswa.edit', $item->id)); ?>" class="btn btn-info">Edit</a>
                                    </div>
                                </td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
    </div>
    <!-- /.container-fluid -->
    <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!-- Pay confirm Modal -->
    <div class="modal fade" id="pay-confirm-modal-<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Modal Title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(url('konfirmasi-pembayaran')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="required">Konfirmasi Pembayaran</label>
                            <select name="konfirmasi"  class="form-control">
                                <option value="">-- PILIH STATUS --</option>
                                <option value="yes">Pembayaran Sudah Masuk dan Terverifikasi</option>
                                <option value="no">Pembayaran Belum Terverifikasi</option>
                            </select>
                        </div>
                        <input type="hidden" name="id" id="id-siswa-<?php echo e($item->id); ?>">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-primary">Konfirmasi</button>
                    </div>
                </form>
            </div>
        </div>
    </div>   
    <!-- /Pay confirm Modal -->
    <!-- Insert Note Modal -->
    <div class="modal fade" id="insert-note-<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="insert-note-title" id="exampleModalLabel">Modal Title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(url('insert-note')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="required">Tambah Note </label>
                            <textarea name="note" id="" cols="70" class="form-control" rows="5"></textarea>
                        </div>
                        <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-primary">Konfirmasi</button>
                    </div>
                </form>
            </div>
        </div>
    </div>   
    <!-- /Insert Note Modal -->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- /Import Modal -->
    <div class="modal fade" id="import-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 id="exampleModalLabel">Import Data</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(url('import-siswa')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="required">Pilih File </label>
                            <input type="file" name="file" required class="form-control">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-primary">Konfirmasi</button>
                    </div>
                </form>
            </div>
        </div>
    </div>   
    <!-- /Import Modal -->
    
    
    <?php $__env->stopSection(); ?>
    
    <?php $__env->startSection('script'); ?>
    
    <script>
        $('.pay-confirm').on('click', function () {
            var id = $(this).data('id');
            var nama = $(this).data('nama');
            
            $('.modal-title').text('Verifikasi Pembayaran - '+nama);
            $('#id-siswa-'+id).val(id);
            $('#pay-confirm-modal-'+id).modal('show');
        });
    </script>
    <script>
        $('.insert-note').on('click', function () {
            var id = $(this).data('id');
            var nama = $(this).data('nama');
            
            $('.insert-note-title').text('Tambah Note - '+nama);
            $('#id-siswa-'+id).val(id);
            $('#insert-note-'+id).modal('show');
        });
    </script>
    <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <script>
        $('.import').on('click', function () {

            $('#import-modal').modal('show');
        });
    </script>
    <script>
        $('#change-level-<?php echo e($item->id); ?>').on('change', function() {
            var userConfirmed = confirm('Yakin Ganti Level?');
            
            if (userConfirmed) {
                var id = $(this).data('id');
                var level = $(this).val();
                var csrfToken = "<?php echo e(csrf_token()); ?>";
                
                $.ajax({
                    url:'change-level',
                    method:'POST',
                    headers:{
                        'X-CSRF-TOKEN':csrfToken
                    },
                    data:{
                        id:id,
                        level:level
                    },
                    success: function(response){
                        console.log(response);
                    },
                    error: function(error){
                        console.log(error);
                    }
                })
            }
        })
    </script>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <script>
        $('.change-status').on('change', function(){
            var userConfirmed = confirm('Yakin Ganti Status?');
            
            if (userConfirmed) {
                var id = $(this).data('id');
                var status = $(this).val();
                var csrfToken = "<?php echo e(csrf_token()); ?>";
                
                $.ajax({
                    url:'change-status/'+id,
                    method:'POST',
                    headers:{
                        'X-CSRF-TOKEN':csrfToken
                    },
                    data:{
                        status:status,
                    },
                    success:function(response){
                        console.log(response);
                    },
                    error: function(error){
                        console.log(error);
                    }
                    
                });
            }
            
        })
    </script>
    <script src="<?php echo e(asset('printThis-master/printThis.js')); ?>"></script>
    <script>
        $('#print').on('click', function() {
            $("#print-this").printThis();
        })
        
    </script>
    <?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\M. Rivaldi Anwar Putra\bimbel1501\resources\views/siswa/index.blade.php ENDPATH**/ ?>