<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
    <thead>
        <tr>
            <th>Nama</th>
            <th>Jumlah Kelas</th>
   
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $unit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item->nama); ?></td>
            <td><?php echo e($item->jumlahKelas()); ?></td>

        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\M. Rivaldi Anwar Putra\bimbel1501\resources\views/exports/unit.blade.php ENDPATH**/ ?>