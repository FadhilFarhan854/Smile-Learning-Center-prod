<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
    <thead>
        <tr>
            <th>Kelas</th>
            <th>Siswa</th>
            <th>Status</th>
            <th>SPP</th>
            <th>Pembayaran</th>
            <th>Level</th>
            <th>Baca</th>
            <th>Tulis</th>
            <th>Hitung</th>
            <th>Modul SD</th>
            <th>English</th>
            <th>Iqro</th>
            <th>Pendaftaran Set</th>
            <th>Modul Lain</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item->kelas->nama); ?></td>
            <td><?php echo e($item->nama); ?></td>
            <td>
                <?php if(optional($item->checkSPP($month, $year))->verified == 'yes'): ?>
                <span class="<?php echo e($item->checkStatus($item->checkSPP($month, $year)->status)); ?>"><?php echo e(ucwords($item->checkSPP($month, $year)->status)); ?></span>
                <?php else: ?>
                <span >Menunggu konfirmasi</span>
                <?php endif; ?>
            </td>
            <td>
              

                <?php if(count($item->spp->where('bulan', $month)->where('tahun', $year)) > 0 && $item->checkSPP($month, $year)->verified == 'yes'): ?>
                <span><?php echo e($item->spp->where('bulan', $month)->where('tahun', $year)->first()->tanggal != null ? formattedDate($item->spp->where('bulan', $month)->where('tahun', $year)->first()->tanggal) : ''); ?></span>
                <?php else: ?>
                <span class="text-danger">Belum dikonfirmasi</span>
                <?php endif; ?>

               
            </td>
            <td>
          

                <?php if(count($item->additional->where('bulan', $month)->where('tahun', $year))): ?>
                <span><?php echo e($item->additional->where('bulan', $month)->where('tahun', $year)->first()->status); ?></span>
                <?php else: ?>
                <span class="text-danger">Belum dikonfirmasi</span>
                <?php endif; ?>

            
            </td>
            <td class="td-min">
                <?php if($item->checkOrder($month, $year)): ?>
                <?php echo e($item->checkOrder($month, $year)->level); ?>

                <?php else: ?>
                --
                <?php endif; ?>
            </td>
            <td class="td-min">
                <?php if($item->checkOrderSpec($month, $year, 'baca')): ?>
                <?php echo e($item->checkOrderSpec($month, $year, 'baca')->modul->nama ?? '--'); ?>

                
                <?php endif; ?>
            </td>
            <td class="td-min">
                <?php if($item->checkOrderSpec($month, $year, 'tulis')): ?>
                <?php echo e($item->checkOrderSpec($month, $year, 'tulis')->modul->nama ?? '--'); ?>

               
                <?php endif; ?>
                
            </td>
            <td class="td-min">
                <?php if($item->checkOrderSpec($month, $year, 'hitung')): ?>
                <?php echo e($item->checkOrderSpec($month, $year, 'hitung')->modul->nama ?? '--'); ?>

               
                <?php endif; ?>
            </td>
            <td class="td-min">
                <?php if($item->checkOrderSpec($month, $year, 'modul SD')): ?>
                <?php echo e($item->checkOrderSpec($month, $year, 'modul SD')->modul->nama ?? '--'); ?>

               
                <?php endif; ?>
            </td>
            <td class="td-min">
                <?php if($item->checkOrderSpec($month, $year, 'english')): ?>
                <?php echo e($item->checkOrderSpec($month, $year, 'english')->modul->nama ?? '--'); ?>

               
                <?php endif; ?>
            </td>
            <td class="td-min">
                <?php if($item->checkOrderSpec($month, $year, 'iqro')): ?>
                <?php echo e($item->checkOrderSpec($month, $year, 'iqro')->modul->nama ?? '--'); ?>

              
                <?php endif; ?>
            </td>
            <td class="td-min">
                <?php if($item->checkOrderSpec($month, $year, 'daftar')): ?>
                <?php echo e($item->checkOrderSpec($month, $year, 'daftar')->modul->nama ?? '--'); ?>

              
                <?php endif; ?>
            </td>
            <td class="td-min">
                <?php if($item->checkOrderSpec($month, $year, 'lain')): ?>
                <?php echo e($item->checkOrderSpec($month, $year, 'lain')->modul->nama ?? '--'); ?>

               
                <?php endif; ?>
            </td>
            <td>
               
                <div class="d-flex justify-content-start">
                    <?php if($item->checkOrder($month, $year)): ?>
                    <span>Sudah di Submit</span> 
                    <?php elseif(!$item->checkSPP($month, $year) || $item->checkSPP($month, $year)->verified == 'no'): ?>
                    <span class="text-danger">Pembayaran Belum disetujui Administrator</span>
                    <?php elseif($item->checkSPP($month, $year)->status == 'keluar'): ?>
                    <span class="text-danger">Siswa Keluar</span>
                    <?php else: ?>
                    <span>Belum disubmit</span>
                    <?php endif; ?>
                </div>
               
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH /var/www/vhosts/exakarya.com/bimbel.exakarya.com/resources/views/exports/order.blade.php ENDPATH**/ ?>