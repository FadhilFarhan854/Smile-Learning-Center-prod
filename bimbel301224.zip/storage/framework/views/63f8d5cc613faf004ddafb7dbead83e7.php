

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    
    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Absensi</h1>
    <?php if(session('status')): ?>
    <div class="alert alert-success">
        <?php echo e(session('status')); ?>

    </div>
    <?php endif; ?>
    
    <?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
    <?php endif; ?>
    <!-- DataTales Example -->
    
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <div class="row">
                <div class="d-flex justify-content-around col-lg-8">
                    <?php for($i = 1; $i <= 12; $i++): ?>
                    <form action="<?php echo e(route('absen.index')); ?>" method="get">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('get'); ?>
                        <input type="hidden" name="month" value="<?php echo e($i); ?>">
                        <input type="hidden" name="tahun" value="<?php echo e($year); ?>">
                        <button type="submit" class="btn btn-light <?php echo e($month == $i ? 'active' : ''); ?>"><?php echo e($months[$i]); ?></button>
                    </form>
                    <?php endfor; ?>
                </div>
                <div class="col-lg-4 d-flex justify-content-between">
                    <select name="tahun" id="change-tahun" class="form-control mr-4" data-month="<?php echo e($month); ?>">
                        <?php for($i = $year+1; $i > $year-4; $i--): ?>
                        <option value="<?php echo e($i); ?>" <?php echo e($year == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                        <?php endfor; ?>
                    </select>         
                    <button id="print" class="btn btn-info"> Print </button>          
                </div>
            </div>
        </div>
        <div class="card-body" id="print-this">
            <div class="row mt-0 pt-0 justify-content-between">
                <div class="col-lg-5 ">
                    <button type="button" class="transparent-button f-13 p-1  input-absen" ><i class="font-small fa fa-check text-success "></i></button> <span class="font-small"> <i class="fa fa-arrow-right"></i> Masuk</span> |
                    <button type="button" class="transparent-button f-13 p-1  input-absen"><i class="font-small fa fa-times text-danger"></i> </button> <span class="font-small"> <i class="fa fa-arrow-right"></i> Alfa</span> |
                    <button type="button" class=" font-small badge badge-primary f-10 p-1  border input-absen"><i class="font-small fa fa-clock"></i> </button> <span class="font-small"><i class="fa fa-arrow-right"></i> Cuti</span> |
                    <button type="button" class="font-small badge badge-danger f-10 p-1  border input-absen"><i class="font-small fa fa-stethoscope "></i> </button> <span class="font-small"><i class="fa fa-arrow-right"></i> Sakit</span> |
                    <button type="button" class="font-small badge badge-warning f-10 p-1  border input-absen"><i class="font-small fa fa-calendar"></i> </button> <span class="font-small"><i class="fa fa-arrow-right"></i> Izin</span> 
                </div>
                <div class="d-flex">
                    <label class="mt-2">Unit:</label>
                    <select name="unit" id="change-unit" class="form-control ml-2"  form="unit-form">
                        <option value="">All</option>
                        <?php $__currentLoopData = $unit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ut): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($ut->id); ?>" <?php echo e($reqUnit == $ut->id ? 'selected' : ''); ?>><?php echo e($ut->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <input type="hidden" name="month" value="<?php echo e($month); ?>" form="unit-form">
                    <input type="hidden" name="tahun" value="<?php echo e($year); ?>" form="unit-form">
                    <input type="hidden" name="kelas" value="<?php echo e($reqKelas); ?>" form="unit-form">
                    <label class="mt-2 ml-3">Kelas:</label>
                    <select name="kelas" id="change-kelas" class="form-control ml-2"  form="kelas-form">
                        <option value="">All</option>
                        <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($kl->id); ?>" <?php echo e($reqKelas == $kl->id ? 'selected' : ''); ?>><?php echo e($kl->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <input type="hidden" name="month" value="<?php echo e($month); ?>" form="kelas-form">
                    <input type="hidden" name="tahun" value="<?php echo e($year); ?>" form="kelas-form">
                    <input type="hidden" name="unit" value="<?php echo e($reqUnit); ?>" form="kelas-form">
                </div>
            </div>
            <div class="table-responsive mt-2">
                <table class="table-absen "  width="100%" cellspacing="0">
                    <thead class="mt-5"> 
                        <tr>
                            <th class="px-44 f-9 th-judul">Nama Siswa</th>
                            <?php for($i = 1; $i <= $daysInMonth; $i++): ?>
                            <th class="px-44 f-9 th-absen"><?php echo e($i); ?> <br><?php echo e($weekMap[\Carbon\Carbon::parse(\Carbon\Carbon::parse($i . '-' . $month . '-' . $year))->dayOfWeek]); ?></th>
                            <?php endfor; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr> 
                            <td class="td-judul"><?php echo e($item->nama); ?></td>
                            <?php $__currentLoopData = $dateToFill[$item->id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td class="td-absen">
                                <?php if($it == 'PRE' || $it == 'POST'): ?>
                                -
                                <?php elseif($it == 'EMPTY'): ?>
                                <button type="button" class="badge badge-light f-10 p-1 border input-absen" data-toggle="modal" data-target="input-absen-<?php echo e($item->id); ?>" data-id="<?php echo e($item->id); ?>" data-date="<?php echo e($key); ?>" data-month="<?php echo e($month); ?>" data-year="<?php echo e($year); ?>" data-nama="<?php echo e($item->nama); ?>"><i class="fa fa-plus text-secondary"></i></button>
                                <?php elseif($it == 'masuk'): ?>
                                <button type="button" class="transparent-button f-13 p-1  input-absen" data-toggle="modal" data-target="input-absen-<?php echo e($item->id); ?>" data-id="<?php echo e($item->id); ?>" data-date="<?php echo e($key); ?>" data-month="<?php echo e($month); ?>" data-year="<?php echo e($year); ?>" data-nama="<?php echo e($item->nama); ?>"><i class="fa fa-check text-success "></i></button>
                                <?php elseif($it == 'alfa'): ?>
                                <button type="button" class="transparent-button f-13 p-1  input-absen" data-toggle="modal" data-target="input-absen-<?php echo e($item->id); ?>" data-id="<?php echo e($item->id); ?>" data-date="<?php echo e($key); ?>" data-month="<?php echo e($month); ?>" data-year="<?php echo e($year); ?>" data-nama="<?php echo e($item->nama); ?>"><i class="fa fa-times text-danger"></i> </button>
                                <?php elseif($it == 'cuti'): ?>
                                <button type="button" class="badge badge-primary f-10 p-1  border input-absen" data-toggle="modal" data-target="input-absen-<?php echo e($item->id); ?>" data-id="<?php echo e($item->id); ?>" data-date="<?php echo e($key); ?>" data-month="<?php echo e($month); ?>" data-year="<?php echo e($year); ?>" data-nama="<?php echo e($item->nama); ?>"><i class="fa fa-clock"></i> </button>
                                <?php elseif($it == 'sakit'): ?>
                                <button type="button" class="badge badge-danger f-10 p-1  border input-absen" data-toggle="modal" data-target="input-absen-<?php echo e($item->id); ?>" data-id="<?php echo e($item->id); ?>" data-date="<?php echo e($key); ?>" data-month="<?php echo e($month); ?>" data-year="<?php echo e($year); ?>" data-nama="<?php echo e($item->nama); ?>"><i class="fa fa-stethoscope "></i> </button>
                                <?php elseif($it == 'izin'): ?>
                                <button type="button" class="badge badge-warning f-10 p-1  border input-absen" data-toggle="modal" data-target="input-absen-<?php echo e($item->id); ?>" data-id="<?php echo e($item->id); ?>" data-date="<?php echo e($key); ?>" data-month="<?php echo e($month); ?>" data-year="<?php echo e($year); ?>" data-nama="<?php echo e($item->nama); ?>"><i class="fa fa-calendar"></i> </button>
                                <?php endif; ?>
                            </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- Form Change Unit -->
<form class="ml-3" action="<?php echo e(route('absen.index')); ?>" method="get" id="unit-form">
    <?php echo csrf_field(); ?>
</form>
<!-- /Form Change Unit -->
<!-- Form Change Kelas -->
<form class="ml-3" action="<?php echo e(route('absen.index')); ?>" method="get" id="kelas-form">
    <?php echo csrf_field(); ?>
</form>
<!-- /Form Change Unit -->
<!-- /.container-fluid -->

<!-- Modal Input Absen -->
<?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="input-absen-<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Modal Title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(route('absen.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="form-group">
                        <label class="required">Status Absen</label>
                        <select name="status" id="" class="form-control required" required>
                            <option value="">-- PILIH --</option>
                            <option value="masuk">Masuk</option>
                            <option value="cuti">Cuti</option>
                            <option value="alfa">Alfa</option>
                            <option value="izin">Izin</option>
                            <option value="sakit">Sakit</option>
                        </select>
                    </div>
                    <input type="hidden" name="siswa_id" value="<?php echo e($item->id); ?>">
                    <input type="hidden" name="date" class="date-absen">
                    <input type="hidden" name="month" value="<?php echo e($month); ?>">
                    <input type="hidden" name="year" value="<?php echo e($year); ?>">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary">Konfirmasi</button>
                </div>
            </form>
        </div>
    </div>
</div>   
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- /Modal Input Absen -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $('#change-tahun').on('change', function () {
        var tahun = $(this).val();
        var month = $(this).data('month');
        var csrfToken = "<?php echo e(csrf_token()); ?>"
        
        $.ajax({
            url: "<?php echo e(route('absen.index')); ?>",
            method: 'GET',
            headers: {
                'X-CSRF-TOKEN': csrfToken
            },
            data: {
                tahun: tahun,
                month: month // Make sure the key matches the controller's parameter
            },
            dataType: 'html', // Expect HTML response
            success: function(response) {
                // Update the entire HTML of the document
                document.open();
                document.write(response);
                document.close();
                
                var newUrl = window.location.pathname + '?tahun=' + tahun + '&month=' + month;
                window.history.pushState({}, '', newUrl);
            },
            error: function (error) {
                console.log(error);
            }
        });
        
    })
</script>
<?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<script>
    $(document).ready(function () {
        $('.input-absen').on('click', function () {
            var id = $(this).data('id');
            var date = $(this).data('date');
            var month = $(this).data('month');
            var year = $(this).data('year');
            var nama = $(this).data('nama');
            
            $('.modal-title').text('Absen - '+nama+' : '+date+'/'+month+'/'+year);
            $('.date-absen').val(date);
            $('#input-absen-'+id).modal('show');
        });
    });
</script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script src="<?php echo e(asset('printThis-master/printThis.js')); ?>"></script>
<script>
    $('#print').on('click', function() {
        $("#print-this").printThis();
    })
    
</script>
<script>
    $('#change-unit').on('change', function() {
        $('#unit-form').submit();
    });

    $('#change-kelas').on('change', function() {
        $('#kelas-form').submit();
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\M. Rivaldi Anwar Putra\bimbel\resources\views/absen/index.blade.php ENDPATH**/ ?>