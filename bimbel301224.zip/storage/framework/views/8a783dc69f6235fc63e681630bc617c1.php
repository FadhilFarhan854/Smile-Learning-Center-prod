<table class="table-absen "  width="100%" cellspacing="0">
    <thead class="mt-5"> 
        <tr>
            <th class="px-44 f-9 th-judul">Data Absen Siswa, Bulan <?php echo e($month); ?> Tahun <?php echo e($year); ?></th>
            <?php for($i = 1; $i <= $daysInMonth; $i++): ?>
            <th class="px-44 f-9 th-absen"><?php echo e($i); ?> <br><?php echo e($weekMap[\Carbon\Carbon::parse(\Carbon\Carbon::parse($i . '-' . $month . '-' . $year))->dayOfWeek]); ?></th>
            <?php endfor; ?>
            <th class="px-44 f-9 th-absen">Total <br> Hadir</th>
            <th class="px-44 f-9 th-absen">Ket</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr> 
            <td class="td-judul"><?php echo e($item->nama); ?></td>
            <?php $__currentLoopData = $dateToFill[$item->id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
            <td class="td-absen">
                <?php if($it == 'PRE' || $it == 'POST'): ?>
                -
                <?php elseif($it == 'EMPTY'): ?>
                <button type="button" class="badge badge-light f-10 p-1 border " data-toggle="modal" data-target="input-absen-<?php echo e($item->id); ?>" data-id="<?php echo e($item->id); ?>" data-date="<?php echo e($key); ?>" data-month="<?php echo e($month); ?>" data-year="<?php echo e($year); ?>" data-nama="<?php echo e($item->nama); ?>"><i class="fa fa-plus text-secondary"></i></button>
                <?php elseif($it == 'masuk'): ?>
                Hadir
                <?php elseif($it == 'alfa'): ?>
                Alfa
                <?php elseif($it == 'cuti'): ?>
                Cuti
                <?php elseif($it == 'sakit'): ?>
                Sakit
                <?php elseif($it == 'izin'): ?>
                Izin
                <?php endif; ?>
            </td>
           
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <td class="transparent-button f-13 p-1  input-absen"><?php echo e($item->countAbsen($month, $year)); ?></td>
            <td class="transparent-button f-13 p-1  input-absen">
              <?php if($item->checkAbsenNotes($month, $year) ): ?>
              <button type="button" class="badge badge-warning f-10 p-1  border edit-notes" data-id="<?php echo e($item->id); ?>" data-month="<?php echo e($month); ?>" data-year="<?php echo e($year); ?>" data-nama="<?php echo e($item->nama); ?>"><i class="fas fa-sticky-note"></i> </button>
              <?php else: ?>
              <button type="button" class="badge badge-info f-10 p-1  border input-notes" data-id="<?php echo e($item->id); ?>" data-month="<?php echo e($month); ?>" data-year="<?php echo e($year); ?>" data-nama="<?php echo e($item->nama); ?>"><i class="fa fa-plus"></i> </button>
              <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH /var/www/vhosts/exakarya.com/bimbel.exakarya.com/resources/views/exports/absen.blade.php ENDPATH**/ ?>