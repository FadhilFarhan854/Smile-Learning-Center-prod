

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    
    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Edit Siswa</h1>
    
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="col-lg-6 offset-lg-2">
                <form action="<?php echo e(route('siswa.update', $siswa->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <div class="form-group">
                        <label class="required">Kelas</label>
                        <select name="kelas_id" class="form-control" required>
                            <option value="">-- PILIH KELAS --</option>
                            <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" <?php echo e($siswa->kelas_id == $item->id ? 'selected' : ''); ?>><?php echo e($item->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="required">Nama Siswa</label>
                        <input type="text" class="form-control" name="nama" required value="<?php echo e($siswa->nama); ?>">
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label class="required">NIM</label>
                                <input type="number" class="form-control" name="nim" required value="<?php echo e($siswa->nim); ?>">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label class="required">Tanggal Masuk</label>
                                <input type="date" class="form-control" name="tanggal_masuk" required value="<?php echo e($siswa->tanggal_masuk); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label class="required">Tempat Lahir</label>
                                <input type="text" class="form-control" name="tempat_lahir" required value="<?php echo e($siswa->tempat_lahir); ?>">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label class="required">Tanggal Lahir</label>
                                <input type="date" class="form-control" name="tanggal_lahir" required value="<?php echo e($siswa->tanggal_lahir); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="row mt-2">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label class="required">Nama Ayah</label>
                                <input type="text" class="form-control" name="nama_ayah" required value="<?php echo e($siswa->nama_ayah); ?>">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label class="required">Nama Ibu</label>
                                <input type="text" class="form-control" name="nama_ibu" required value="<?php echo e($siswa->nama_ibu); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <button class="btn btn-success" type="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
</div>
<!-- /.container-fluid -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\M. Rivaldi Anwar Putra\bimbel\resources\views/siswa/edit.blade.php ENDPATH**/ ?>