

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    
    <!-- Page Heading -->
    <div class="d-flex justify-content-start">
        <h1 class="h3 mb-2 text-gray-800">Data Modul</h1><button class="btn btn-info ml-3" id="print"><i class="fa fa-print"></i> Print</button>
        <a href="<?php echo e(url('export-modul')); ?>" class="btn btn-success ml-3"><i class="fa fa-download"></i> Export</a>
    </div>
    <?php if(session('status')): ?>
    <div class="alert alert-success">
        <?php echo e(session('status')); ?>

    </div>
    <?php endif; ?>
    
    <?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
    <?php endif; ?>
    <!-- DataTales Example -->
    <div class="card shadow mb-4" id="print-this">
        <div class="card-header py-3">
            <?php if(auth()->user()->role != 'administrator 2'): ?>
            <a href="<?php echo e(route('modul.create')); ?>" class="btn btn-success">Tambah Modul</a>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Nama</th>
                            <th>Level</th>
                            <th>Kategori</th>
                            <?php if(auth()->user()->role != 'administrator 2'): ?>
                            <th>Action</th>
                            <?php endif; ?>
                            <th>Stock</th>
                           
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $modul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->nama); ?></td>
                            <td><?php echo e($item->level); ?></td>
                            <td><?php echo e(ucwords($item->kategori)); ?></td>
                            <?php if(auth()->user()->role != 'administrator 2'): ?>
                            <td>
                                <div class="d-flex justify-content-start">
                                    <a href="<?php echo e(route('modul.edit', $item->id)); ?>" class="btn btn-info">Edit</a>
                                    <form class="ml-3" action="<?php echo e(route('modul.destroy', $item->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button class="btn btn-danger" onclick="return confirm('Yakin Hapus Data?')">Hapus</button>
                                    </form>
                                </div>
                            </td>
                            <?php endif; ?>
                            <td class="d-flex justify-content-around">
                                <?php if(auth()->user()->role != 'administrator 2'): ?>
                                <a data-toggle="modal" class="btn transparent-button kurang-stock m-0 p-0" data-id="<?php echo e($item->id); ?>" data-nama="<?php echo e($item->nama); ?>"><i class="fa fa-minus text-primary"></i></a>
                                <?php endif; ?>
                                <?php echo e($item->countStock()); ?> 
                                <?php if(auth()->user()->role != 'administrator 2'): ?>
                                <a data-toggle="modal" class="btn transparent-button tambah-stock m-0 p-0" data-id="<?php echo e($item->id); ?>" data-nama="<?php echo e($item->nama); ?>"><i class="fa fa-plus text-primary"></i></a>
                                <?php endif; ?>
                            </td>
                            
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
</div>
<!-- /.container-fluid -->
<!-- Modal Add Modul -->
<?php $__currentLoopData = $modul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="tambah-stock-<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Modal Title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(url('tambah-stock/'.$item->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <div class="modal-body">
                    <div class="form-group">
                        <label class="required">Jumlah</label>
                        <input type="number" name="stock" class="form-control" required min="0">
                    </div>
                    <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary">Konfirmasi</button>
                </div>
            </form>
        </div>
    </div>
</div>   
<!-- / Modal Tambah Modul -->
<!-- Modal Kurang Stock -->
<div class="modal fade" id="kurang-stock-<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title-kurang" id="exampleModalLabel">Modal Title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(url('kurang-stock/'.$item->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <div class="modal-body">
                    <div class="form-group">
                        <label class="required">Jumlah</label>
                        <input type="number" name="stock" class="form-control" required min="0">
                    </div>
                    <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary">Konfirmasi</button>
                </div>
            </form>
        </div>
    </div>
</div>   
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!--/Modal Kurang Stock -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__currentLoopData = $modul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<script>
    $('.tambah-stock').on('click', function(){
        var id = $(this).data('id');
        var nama = $(this).data('nama');

        $('.modal-title').text('Tambah Stock '+nama);

        $('#tambah-stock-'+id).modal('show');
    })

    $('.kurang-stock').on('click', function(){
        var id = $(this).data('id');
        var nama = $(this).data('nama');

        $('.modal-title-kurang').text('Kurangi Stock '+nama);

        $('#kurang-stock-'+id).modal('show');
    })
</script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script src="<?php echo e(asset('printThis-master/printThis.js')); ?>"></script>
<script>
    $('#print').on('click', function() {
        $("#print-this").printThis();
    })
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/edakarya.com/bimbel.edakarya.com/resources/views/modul/index.blade.php ENDPATH**/ ?>