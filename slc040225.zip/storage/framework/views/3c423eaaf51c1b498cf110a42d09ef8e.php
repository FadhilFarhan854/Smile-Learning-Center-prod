<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
    <thead>
        <tr>
            <th>Nama</th>
            <th>Level</th>
            <th>Kategori</th>

            <th>Stock</th>
           
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $modul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item->nama); ?></td>
            <td><?php echo e($item->level); ?></td>
            <td><?php echo e(ucwords($item->kategori)); ?></td>
   
            <td class="d-flex justify-content-around">
 
                <?php echo e($item->countStock()); ?> 
        
            </td>
            
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\M. Rivaldi Anwar Putra\bimbel1501\resources\views/exports/modul.blade.php ENDPATH**/ ?>