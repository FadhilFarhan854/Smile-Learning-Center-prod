

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    
    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Edit Order</h1>
    
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="col-lg-6 offset-lg-2">
                <form action="<?php echo e(route('order.update', $order->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <div class="form-group">
                        <label class="required">Level</label>
						<?php if(auth()->user()->role != 'administrator 2'): ?>     
						<select name="level" required class="form-control">
                            <option value="">-- PILIH --</option>
                            <?php for($i = 1; $i < 10; $i++): ?>
                            <option value="<?php echo e($i); ?>" <?php echo e($order->level == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                            <?php endfor; ?>
                        </select>
						<?php else: ?>
                        <select name="level" required class="form-control">
                            <option value="">-- PILIH --</option>
                            <?php for($i = 1; $i < 10; $i++): ?>
                            <option value="<?php echo e($i); ?>" <?php echo e($i < $order->level ? 'disabled' : ''); ?> <?php echo e($order->level == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                            <?php endfor; ?>
                        </select>
						<?php endif; ?>
                    </div>
                    
                    <div class="form-group">
                        <label >Modul Baca</label>
                        <select class="form-control" id="modul-baca">
                            <option value="">--</option>
                            <?php $__currentLoopData = $order->siswa->chooseModul('baca'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>" <?php echo e($baca->modul_id == $md->id ? 'selected' : ''); ?>>Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="hidden" name="modul_baca" id="input-baca" value="<?php echo e(null); ?>">
                        <?php if(session('error-baca-'.$order->siswa_id)): ?>
                        <div class="alert alert-danger p-1">
                            <?php echo e(session('error-baca-'.$order->siswa_id)); ?>

                        </div>
                        <?php endif; ?>
                    </div>
                    
                    
                    <div class="form-group">
                        <label >Modul Tulis</label>
                        <select  class="form-control" id="modul-tulis">
                            <option value="">--</option>
                            <?php $__currentLoopData = $order->siswa->chooseModulAll('tulis'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>" <?php echo e($tulis->modul_id == $md->id ? 'selected' : ''); ?>>Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="hidden" name="modul_tulis" id="input-tulis" value="<?php echo e(null); ?>">
                        <?php if(session('error-tulis-'.$order->siswa_id)): ?>
                        <div class="alert alert-danger p-1">
                            <?php echo e(session('error-tulis-'.$order->siswa_id)); ?>

                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group">
                        <label>Modul Hitung</label>
                        <select class="form-control" id="modul-hitung">
                            <option value="">--</option>
                            <?php $__currentLoopData = $order->siswa->chooseModulAll('hitung'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>" <?php echo e($hitung->modul_id == $md->id ? 'selected' : ''); ?>>Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="hidden" name="modul_hitung" id="input-hitung" value="<?php echo e(null); ?>">
                        <?php if(session('error-hitung-'.$order->siswa_id)): ?>
                        <div class="alert alert-danger p-1">
                            <?php echo e(session('error-hitung-'.$order->siswa_id)); ?>

                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group">
                        <label >Modul SD</label>
                        <select class="form-control" id="modul-sd">
                            <option value="">--</option>
                            <?php $__currentLoopData = $order->siswa->chooseModulAll('modul SD'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>" <?php echo e($modul_sd->modul_id == $md->id ? 'selected' : ''); ?>>Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="hidden" name="modul_sd" id="input-sd" value="<?php echo e(null); ?>">
                        <?php if(session('error-sd-'.$order->siswa_id)): ?>
                        <div class="alert alert-danger p-1">
                            <?php echo e(session('error-sd-'.$order->siswa_id)); ?>

                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group">
                        <label >Modul English</label>
                        <select class="form-control" id="modul-english">
                            <option value="">--</option>
                            <?php $__currentLoopData = $order->siswa->chooseModulAll('english'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>" <?php echo e($english->modul_id == $md->id ? 'selected' : ''); ?>>Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="hidden" name="english" id="input-english" value="<?php echo e(null); ?>">
                        <?php if(session('error-english-'.$order->siswa_id)): ?>
                        <div class="alert alert-danger p-1">
                            <?php echo e(session('error-english-'.$order->siswa_id)); ?>

                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group">
                        <label>Iqro</label>
                        <select class="form-control" id="modul-iqro">
                            <option value="">--</option>
                            <?php $__currentLoopData = $order->siswa->chooseModulAll('iqro'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>" <?php echo e($iqro->modul_id == $md->id ? 'selected' : ''); ?>>Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="hidden" name="iqro" id="input-iqro" value="<?php echo e(null); ?>">
                        <?php if(session('error-iqro-'.$order->siswa_id)): ?>
                        <div class="alert alert-danger p-1">
                            <?php echo e(session('error-iqro-'.$order->siswa_id)); ?>

                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group">
                        <label >Modul Lain</label>
                        <select class="form-control" id="modul-lain">
                            <option value="">--</option>
                            <?php $__currentLoopData = $order->siswa->chooseModulAll('lain'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>" <?php echo e($lain->modul_id == $md->id ? 'selected' : ''); ?>>Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="hidden" name="lain" id="input-lain" value="<?php echo e(null); ?>">
                        <?php if(session('error-lain-'.$order->siswa_id)): ?>
                        <div class="alert alert-danger p-1">
                            <?php echo e(session('error-lain-'.$order->siswa_id)); ?>

                        </div>
                        <?php endif; ?>
                    </div>
                    <input type="hidden" name="siswa" value="<?php echo e($order->siswa_id); ?>">
                    <input type="hidden" name="month" value="<?php echo e($order->bulan); ?>">
                    <input type="hidden" name="tahun" value="<?php echo e($order->tahun); ?>">
                    <input type="hidden" name="status" value="<?php echo e($order->status); ?>">
                    <div class="form-group">
                        <button class="btn btn-success" type="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
</div>
<!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $('#modul-baca').on('change', function(){
            var modul = $(this).val();

            $('#input-baca').val(modul);
        });

        $('#modul-tulis').on('change', function(){
            var modul = $(this).val();

            $('#input-tulis').val(modul);
        });

        $('#modul-hitung').on('change', function(){
            var modul = $(this).val();

            $('#input-hitung').val(modul);
        });

        $('#modul-sd').on('change', function(){
            var modul = $(this).val();

            $('#input-sd').val(modul);
        });

        $('#modul-english').on('change', function(){
            var modul = $(this).val();

            $('#input-english').val(modul);
        });

        $('#modul-iqro').on('change', function(){
            var modul = $(this).val();

            $('#input-iqro').val(modul);
        });

        $('#modul-lain').on('change', function(){
            var modul = $(this).val();

            $('#input-lain').val(modul);
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/exakarya.com/bimbel.exakarya.com/resources/views/order/edit.blade.php ENDPATH**/ ?>