<!-- Sidebar - Brand -->
<a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
    <div class="sidebar-brand-icon ">
        <img src="<?php echo e(asset('admin/img/slc.png')); ?>" style="width: 90px" alt="">
    </div>
    <div class="sidebar-brand-text mx-3">Smile Learning Center</div>
</a><?php /**PATH /var/www/vhosts/slcmanagement.id/httpdocs/resources/views/include/brand.blade.php ENDPATH**/ ?>