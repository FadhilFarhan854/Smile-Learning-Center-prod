

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    
    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Order</h1>
    <?php if(session('status')): ?>
    <div class="alert alert-success">
        <?php echo e(session('status')); ?>

    </div>
    <?php endif; ?>
    
    <?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
    <?php endif; ?>
    <!-- DataTales Example -->
    
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <div class="row">
                <div class="d-flex justify-content-around col-lg-8">
                    <?php for($i = 1; $i <= 12; $i++): ?>
                    <form action="<?php echo e(route('order.index')); ?>" method="get">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('get'); ?>
                        <input type="hidden" name="month" value="<?php echo e($i); ?>">
                        <input type="hidden" name="tahun" value="<?php echo e($year); ?>">
                        <button type="submit" class="btn btn-light <?php echo e($month == $i ? 'active' : ''); ?>"><?php echo e($months[$i]); ?></button>
                    </form>
                    <?php endfor; ?>
                </div>
                <div class="col-lg-4 d-flex justify-content-between">
                    <select name="tahun" id="change-tahun" class="form-control mr-4" data-month="<?php echo e($month); ?>">
                        <?php for($i = $year+1; $i > $year-4; $i--): ?>
                        <option value="<?php echo e($i); ?>" <?php echo e($year == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                        <?php endfor; ?>
                    </select>
                    <a id="rekap-toggle" class="text-success text-center"><i class="fa fa-2x fa-list-alt"></i><br>Rekap</a>
                    
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Kelas</th>
                            <th>Siswa</th>
                            <th>Status</th>
                            <th>Pembayaran</th>
                            <th>Level</th>
                            <th>Baca</th>
                            <th>Tulis</th>
                            <th>Hitung</th>
                            <th>Modul SD</th>
                            <th>English</th>
                            <th>Iqro</th>
                            <th>Modul Lain</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->kelas->nama); ?></td>
                            <td><?php echo e($item->nama); ?></td>
                            <td>
                                <?php if(($item->checkOrder($month, $year))): ?>
                                <span class="<?php echo e($item->checkStatus($item->checkOrder($month, $year)->status)); ?>"><?php echo e(ucwords($item->checkOrder($month, $year)->status)); ?></span>
                                <?php else: ?>
                                <span class="<?php echo e($item->checkStatus()); ?>"><?php echo e(ucwords($item->status)); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(count($item->spp->where('bulan', $month)->where('tahun', $year)) > 0): ?>
                                <span><?php echo e($item->spp->where('bulan', $month)->where('tahun', $year)->first()->tanggal); ?></span>
                                <?php else: ?>
                                <a data-toggle="modal" data-target="pay-confirm-modal-<?php echo e($item->id); ?>" data-id="<?php echo e($item->id); ?>" data-nama="<?php echo e($item->nama); ?>" class="pay-cnfrm pay-confirm">Klik Untuk Verifikasi</a>
                                <?php endif; ?>
                            </td>
                            <td class="td-min">
                                <?php if($item->checkOrder($month, $year)): ?>
                                <?php echo e($item->checkOrder($month, $year)->level); ?>

                                <?php else: ?>
                                <select name="level" id="change-level-<?php echo e($item->id); ?>" class="form-control" data-id="<?php echo e($item->id); ?>" form="order-form-<?php echo e($item->id); ?>">
                                    <option value="" <?php echo e($item->level != null ? 'disabled' : ''); ?>>N/A</option>
                                    <?php for($i = 1; $i < 10; $i++): ?>
                                    <option value="<?php echo e($i); ?>" <?php echo e($i < $item->level ? 'disabled' : ''); ?> <?php echo e($item->level == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                                    <?php endfor; ?>
                                </select>
                                <?php endif; ?>
                            </td>
                            <td class="td-min">
                                <?php if($item->checkOrderSpec($month, $year, 'baca')): ?>
                                <?php echo e($item->checkOrderSpec($month, $year, 'baca')->modul->nama ?? '--'); ?>

                                <?php else: ?>
                                <select name="modul_baca" id="" class="form-control" form="order-form-<?php echo e($item->id); ?>">
                                    <option value="">--</option>
                                    <?php $__currentLoopData = $item->chooseModul('baca'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>">Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if(session('error-baca-'.$item->id)): ?>
                                <div class="alert alert-danger p-1">
                                    <?php echo e(session('error-baca-'.$item->id)); ?>

                                </div>
                                <?php endif; ?>
                                <?php endif; ?>
                            </td>
                            <td class="td-min">
                                <?php if($item->checkOrderSpec($month, $year, 'tulis')): ?>
                                <?php echo e($item->checkOrderSpec($month, $year, 'tulis')->modul->nama ?? '--'); ?>

                                <?php else: ?>
                                <select name="modul_tulis" id="" class="form-control" form="order-form-<?php echo e($item->id); ?>">
                                    <option value="">--</option>
                                    <?php $__currentLoopData = $item->chooseModul('tulis'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>">Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if(session('error-tulis-'.$item->id)): ?>
                                <div class="alert alert-danger p-1">
                                    <?php echo e(session('error-tulis-'.$item->id)); ?>

                                </div>
                                <?php endif; ?>
                                <?php endif; ?>
                                
                            </td>
                            <td class="td-min">
                                <?php if($item->checkOrderSpec($month, $year, 'hitung')): ?>
                                <?php echo e($item->checkOrderSpec($month, $year, 'hitung')->modul->nama ?? '--'); ?>

                                <?php else: ?>
                                <select name="modul_hitung" id="" class="form-control" form="order-form-<?php echo e($item->id); ?>">
                                    <option value="">--</option>
                                    <?php $__currentLoopData = $item->chooseModul('hitung'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>">Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if(session('error-hitung-'.$item->id)): ?>
                                <div class="alert alert-danger p-1">
                                    <?php echo e(session('error-hitung-'.$item->id)); ?>

                                </div>
                                <?php endif; ?>
                                <?php endif; ?>
                            </td>
                            <td class="td-min">
                                <?php if($item->checkOrderSpec($month, $year, 'modul SD')): ?>
                                <?php echo e($item->checkOrderSpec($month, $year, 'modul SD')->modul->nama ?? '--'); ?>

                                <?php else: ?>
                                <select name="modul_sd" id="" class="form-control" form="order-form-<?php echo e($item->id); ?>">
                                    <option value="">--</option>
                                    <?php $__currentLoopData = $item->chooseModul('modul SD'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>">Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if(session('error-sd-'.$item->id)): ?>
                                <div class="alert alert-danger p-1">
                                    <?php echo e(session('error-sd-'.$item->id)); ?>

                                </div>
                                <?php endif; ?>
                                <?php endif; ?>
                            </td>
                            <td class="td-min">
                                <?php if($item->checkOrderSpec($month, $year, 'english')): ?>
                                <?php echo e($item->checkOrderSpec($month, $year, 'english')->modul->nama ?? '--'); ?>

                                <?php else: ?>
                                <select name="english" id="" class="form-control" form="order-form-<?php echo e($item->id); ?>">
                                    <option value="">--</option>
                                    <?php $__currentLoopData = $item->chooseModul('english'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>">Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if(session('error-english-'.$item->id)): ?>
                                <div class="alert alert-danger p-1">
                                    <?php echo e(session('error-english-'.$item->id)); ?>

                                </div>
                                <?php endif; ?>
                                <?php endif; ?>
                            </td>
                            <td class="td-min">
                                <?php if($item->checkOrderSpec($month, $year, 'iqro')): ?>
                                <?php echo e($item->checkOrderSpec($month, $year, 'iqro')->modul->nama ?? '--'); ?>

                                <?php else: ?>
                                <select name="iqro" id="" class="form-control" form="order-form-<?php echo e($item->id); ?>">
                                    <option value="">--</option>
                                    <?php $__currentLoopData = $item->chooseModul('iqro'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>">Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if(session('error-iqro-'.$item->id)): ?>
                                <div class="alert alert-danger p-1">
                                    <?php echo e(session('error-iqro-'.$item->id)); ?>

                                </div>
                                <?php endif; ?>
                                <?php endif; ?>
                            </td>
                            <td class="td-min">
                                <?php if($item->checkOrderSpec($month, $year, 'lain')): ?>
                                <?php echo e($item->checkOrderSpec($month, $year, 'lain')->modul->nama ?? '--'); ?>

                                <?php else: ?>
                                <select name="lain" id="" class="form-control" form="order-form-<?php echo e($item->id); ?>">
                                    <option value="">--</option>
                                    <?php $__currentLoopData = $item->chooseModul('lain'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($md->id); ?>" style="<?php echo e($md->countStock() <= 0 ?'display:none' : ''); ?>">Level <?php echo e($md->level); ?> : <?php echo e($md->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if(session('error-lain-'.$item->id)): ?>
                                <div class="alert alert-danger p-1">
                                    <?php echo e(session('error-lain-'.$item->id)); ?>

                                </div>
                                <?php endif; ?>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="d-flex justify-content-start">
                                    <input type="hidden" name="month" value="<?php echo e($month); ?>" form="order-form-<?php echo e($item->id); ?>">
                                    <input type="hidden" name="tahun" value="<?php echo e($year); ?>" form="order-form-<?php echo e($item->id); ?>">
                                    <input type="hidden" name="siswa" value="<?php echo e($item->id); ?>" form="order-form-<?php echo e($item->id); ?>">
                                    <input type="hidden" name="status" value="<?php echo e($item->status); ?>" form="order-form-<?php echo e($item->id); ?>">
                                    <?php if($item->checkOrder($month, $year)): ?>
                                    <span>Sudah di Submit</span>
                                    <?php elseif($item->status == 'baru'): ?>
                                    <span class="text-danger">Siswa Belum disetujui Administrator</span>
                                    <?php else: ?>
                                    <button class="btn btn-warning" onclick="return confirm('Yakin Data Sudah Benar?')" type="submit" form="order-form-<?php echo e($item->id); ?>">Submit</button>
                                    <?php endif; ?>
                                    
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form class="ml-3" action="<?php echo e(route('order.store')); ?>" method="post" id="order-form-<?php echo e($item->id); ?>">
    <?php echo csrf_field(); ?>
</form>


<!-- Pay confirm Modal -->
<div class="modal fade" id="pay-confirm-modal-<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Modal Title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(url('konfirmasi-pembayaran')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="form-group">
                        <label class="required">Konfirmasi Pembayaran</label>
                        <select name="konfirmasi"  class="form-control">
                            <option value="">-- PILIH STATUS --</option>
                            <option value="yes">Pembayaran Sudah Masuk dan Terverifikasi</option>
                            <option value="no">Pembayaran Belum Terverifikasi</option>
                        </select>
                    </div>
                    <input type="hidden" name="id" id="id-siswa-<?php echo e($item->id); ?>">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary">Konfirmasi</button>
                </div>
            </form>
        </div>
    </div>
</div>   
<!-- /Pay confirm Modal -->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="modal fade" id="rekap-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Rekap Order <?php echo e($month); ?>-<?php echo e($year); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <table class="table table-bordered" id="rekap-modul">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Modul</th>
                            <th>Permintaan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $orderCounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($item->modul->nama ?? '--'); ?></td>
                            <td><?php echo e($item->count); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </tbody>
                </table>
                <table class="table table-bordered d-none" id="rekap-unit">
                    <thead>
                        <tr>
                            <th>Unit</th>
                            <th>Kelas</th>
                            <th>Nama Modul</th>
                            <th>Jumlah</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $prevUnit = null;
                        $prevKelas = null;
                        $unitRowspan = 0;
                        ?>
                        
                        <?php $__currentLoopData = $ordersByUnit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unitName => $ordersByKelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <?php $__currentLoopData = $ordersByKelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelasName => $ordersByModul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $ordersByModul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modulId => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td <?php echo $unitName === $prevUnit ? "style='border-top:solid 2px #fff'" : ''; ?>><b><?php echo e($unitName !== $prevUnit ? $unitName : ''); ?></b></td>
                            <?php echo $unitName.$kelasName !== $prevKelas ? '<td rowspan=' . ($ordersByKelas[$kelasName]->count()) . '>'. $kelasName .'</td>' : ''; ?>

                            <td><?php echo e($moduls->where('id', $modulId)->first()->nama ?? '-- '); ?></td>
                            <td><?php echo e($count); ?></td>
                        </tr>
                        
                        <?php
                        $prevUnit = $unitName;
                        $prevKelas = $unitName.$kelasName;
                        ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    
                </table>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" id="button-rekap-modul">Unit View</button>
                <button class="btn btn-primary d-none" id="button-rekap-unit">Modul View</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>   
<!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $('#change-tahun').on('change', function () {
        var tahun = $(this).val();
        var month = $(this).data('month');
        var csrfToken = "<?php echo e(csrf_token()); ?>"
        
        $.ajax({
            url: "<?php echo e(route('order.index')); ?>",
            method: 'GET',
            headers: {
                'X-CSRF-TOKEN': csrfToken
            },
            data: {
                tahun: tahun,
                month: month // Make sure the key matches the controller's parameter
            },
            dataType: 'html', // Expect HTML response
            success: function(response) {
                // Update the entire HTML of the document
                document.open();
                document.write(response);
                document.close();
                
                var newUrl = window.location.pathname + '?tahun=' + tahun + '&month=' + month;
                window.history.pushState({}, '', newUrl);
            },
            error: function (error) {
                console.log(error);
            }
        });
        
    })
</script>

<?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<script>
    $('#change-level-<?php echo e($item->id); ?>').on('change', function() {
        var userConfirmed = confirm('Yakin Ganti Level?');
        
        if (userConfirmed) {
            var id = $(this).data('id');
            var level = $(this).val();
            var csrfToken = "<?php echo e(csrf_token()); ?>";
            
            $.ajax({
                url:'change-level',
                method:'POST',
                headers:{
                    'X-CSRF-TOKEN':csrfToken
                },
                data:{
                    id:id,
                    level:level
                },
                success: function(response){
                    console.log(response);
                },
                error: function(error){
                    console.log(error);
                }
            })
        }
    })
</script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script>
    $('#rekap-toggle').on('click', function(){
        $('#rekap-modal').modal('show');
    })
</script>

<script>
    $('#button-rekap-modul').on('click', function(){
        $('#button-rekap-modul').addClass('d-none');
        $('#button-rekap-unit').removeClass('d-none');
        $('#rekap-unit').removeClass('d-none');
        $('#rekap-modul').addClass('d-none');
    })
    
    $('#button-rekap-unit').on('click', function(){
        $('#button-rekap-unit').addClass('d-none');
        $('#button-rekap-modul').removeClass('d-none');
        $('#rekap-modul').removeClass('d-none');
        $('#rekap-unit').addClass('d-none');
    })
</script>

<script>
    $('.pay-confirm').on('click', function () {
        var id = $(this).data('id');
        var nama = $(this).data('nama');
        
        $('.modal-title').text('Verifikasi Pembayaran - '+nama);
        $('#id-siswa-'+id).val(id);
        $('#pay-confirm-modal-'+id).modal('show');
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\M. Rivaldi Anwar Putra\Work\bimbel\resources\views/order/index.blade.php ENDPATH**/ ?>