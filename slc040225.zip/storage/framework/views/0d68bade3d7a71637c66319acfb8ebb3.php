

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    
    <!-- Page Heading -->
    <div class="d-flex justify-content-start">
        <h1 class="h3 mb-2 text-gray-800">Data Kelas</h1><button class="btn btn-info ml-3" id="print"><i class="fa fa-print"></i> Print</button>
    </div>
    <?php if(session('status')): ?>
    <div class="alert alert-success">
        <?php echo e(session('status')); ?>

    </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
    <?php endif; ?>
    <!-- DataTales Example -->
    <div class="card shadow mb-4" id="print-this">
        <div class="card-header py-3">
            <?php if(auth()->user()->role != 'administrator 2'): ?>
            <a href="<?php echo e(route('kelas.create')); ?>" class="btn btn-success">Tambah Kelas</a>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Unit</th>
                            <th>Nama</th>
                            <th>Admin</th>
                            <th>Guru</th>
                            <th>Jumlah Siswa</th>
                            <?php if(auth()->user()->role != 'administrator 2'): ?>
                            <th>Action</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>Unit</th>
                            <th>Nama</th>
                            <th>Admin</th>
                            <th>Guru</th>
                            <th>Jumlah Siswa</th>
                            <?php if(auth()->user()->role != 'administrator 2'): ?>
                            <th>Action</th>
                            <?php endif; ?>
                        </tr> 
                    </tfoot>
                    <tbody>
                        <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->unit->nama); ?></td>
                            <td><?php echo e($item->nama); ?></td>
                            <td id="admin-<?php echo e($item->id); ?>">
                                <?php if(auth()->user()->role != 'administrator 2'): ?>
                                <?php if(isset($item->user->name)): ?>
                                <span class="<?php echo e($item->user->status === 'non-aktif' ? 'text-danger' : ''); ?>"><?php echo e($item->user->name); ?></span>
                                <?php else: ?>
                                <select name="admin" class="form-control change-admin" data-id="<?php echo e($item->id); ?>">
                                    <option value="">-- Pilih Admin --</option>
                                    <?php $__currentLoopData = $admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($ad->id); ?>"><?php echo e($ad->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php endif; ?>
                                <?php else: ?>
                                <span class="<?php echo e(isset($item->user->status) && $item->user->status === 'non-aktif' ? 'text-danger' : ''); ?>"><?php echo e($item->user->name ?? '--'); ?></span>
                                <?php endif; ?>
                            </td>
                            <td id="guru-<?php echo e($item->id); ?>">
                                <?php if(auth()->user()->role != 'administrator 2'): ?>
                                <?php if(isset($item->guru->name)): ?>
                                <span class="<?php echo e($item->guru->status === 'non-aktif' ? 'text-danger' : ''); ?>"><?php echo e($item->guru->name); ?></span>
                                <?php else: ?>
                                <select name="guru" class="form-control change-guru" data-id="<?php echo e($item->id); ?>">
                                    <option value="">-- Pilih Guru --</option>
                                    <?php $__currentLoopData = $guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($gr->id); ?>"><?php echo e($gr->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php endif; ?>
                                <?php else: ?>
                                <span class="<?php echo e(isset($item->guru->status) && $item->guru->status === 'non-aktif' ? 'text-danger' : ''); ?>"><?php echo e($item->guru->name ?? '--'); ?></span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($item->jumlahSiswa()); ?></td>
                            <?php if(auth()->user()->role != 'administrator 2'): ?>
                            <td>
                                <div class="d-flex justify-content-start">
                                    <a href="<?php echo e(route('kelas.edit', $item->id)); ?>" class="btn btn-info">Edit</a>
                                    <form class="ml-3" action="<?php echo e(route('kelas.destroy', $item->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button class="btn btn-danger" onclick="return confirm('Yakin Hapus Data?')">Hapus</button>
                                    </form>
                                </div>
                            </td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
</div>
<!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $('.change-guru').on('change', function () {
        var userConfirm = confirm('Yakin ganti item?');
        
        if (userConfirm) {
            var id = $(this).data('id');
            var guru = $(this).val();
            var csrfToken ="<?php echo e(csrf_token()); ?>";
            
            $.ajax({
                url: 'change-guru',
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN' : csrfToken
                },
                data: {
                    id:id,
                    guru:guru
                },
                success: function (response) {
                    $('#guru-' + response.id).html('<span>'+response.guru+'</span>');
                },
                error: function (error) {
                    console.error(error);
                }
            })
        }
        
    })
</script>
<script>
    $('.change-admin').on('change', function () {
        var confirmUser = confirm('Yakin ganti item?');

        if (confirmUser) {
            var id = $(this).data('id');
            var admin = $(this).val();
            var csrfToken = '<?php echo e(csrf_token()); ?>'

            $.ajax({
                url:'change-admin',
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN' : csrfToken
                },
                data: {
                    id:id,
                    admin:admin
                },
                success: function(response) {
                    $('#admin-' + response.id).html('<span>' + response.admin + '</span>');
                },
                error: function (error) {
                    console.error(error);
                }
            })
        }
    })
</script>
<script src="<?php echo e(asset('printThis-master/printThis.js')); ?>"></script>
<script>
    $('#print').on('click', function() {
        $("#print-this").printThis();
    })
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\M. Rivaldi Anwar Putra\bimbel-2\resources\views/kelas/index.blade.php ENDPATH**/ ?>