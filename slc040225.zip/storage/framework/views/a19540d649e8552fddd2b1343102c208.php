

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    
    <!-- Page Heading -->
    <?php if(session('status')): ?>
    <div class="alert alert-success">
        <?php echo e(session('status')); ?>

    </div>
    <?php endif; ?>
    
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h3>Profil Siswa</h3>
        </div>
        <div class="card-body px-5">
            <div class="row">
                <h5><?php echo e(ucwords($siswa->nama)); ?></h5>
            </div>
            <div class="row mt-4">
                <div class="col-lg-6 p-1">
                    <span class="font-weight-bold">Data Pribadi</span>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6 p-0">
                    <table class="table ">
                        <tbody>
                            <tr >
                                <td class="td-max">NIM</td>
                                <td class="td-max"><?php echo e($siswa->nim); ?></td>
                            </tr>
                            <tr>
                                <td class="td-max">Tanggal Masuk</td>
                                <td class="td-max"><?php echo e(formattedDate($siswa->tanggal_masuk)); ?></td>
                            </tr>
                            <tr>
                                <td class="td-max">Tempat, Tanggal Lahir</td>
                                <td class="td-max"><?php echo e($siswa->tempat_lahir); ?>, <?php echo e(formattedDate($siswa->tanggal_lahir)); ?></td>
                            </tr>
                            <tr>
                                <td class="td-max">Nama Ayah</td>
                                <td class="td-max"><?php echo e(ucwords($siswa->nama_ayah)); ?></td>
                            </tr>
                            <tr>
                                <td class="td-max">Nama Ibu</td>
                                <td class="td-max"><?php echo e(ucwords($siswa->nama_ibu)); ?></td>
                            </tr>
                            <tr>
                                <td class="td-max">Telp/HP Wali</td>
                                <td class="td-max"><?php echo e($siswa->no_wali_1 ?? '--'); ?></td>
                            </tr>
                            <tr>
                                <td class="td-max"></td>
                                <td class="td-max"><?php echo e($siswa->no_wali_2 ?? '--'); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="row mt-2">
                <div class="col-lg-6 p-1">
                    <span class="font-weight-bold">Data Studi</span>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6 p-0">
                    <table class="table">
                        <tbody>
                            <tr >
                                <td class="td-max">Level</td>
                                <td class="td-max"><?php echo e($siswa->level); ?></td>
                            </tr>
                            <tr >
                                <td class="td-max">Modul Baca</td>
                                <td class="td-max"><?php echo e($siswa->latestmodul('baca')->nama ?? '--'); ?></td>
                            </tr>
                            <tr >
                                <td class="td-max">Modul Tulis</td>
                                <td class="td-max"><?php echo e($siswa->latestmodul('tulis')->nama ?? '--'); ?></td>
                            </tr>
                            <tr >
                                <td class="td-max">Modul Hitung</td>
                                <td class="td-max"><?php echo e($siswa->latestmodul('hitung')->nama ?? '--'); ?></td>
                            </tr>
                            <tr >
                                <td class="td-max">Modul SD</td>
                                <td class="td-max"><?php echo e($siswa->latestmodul('modul SD')->nama ?? '--'); ?></td>
                            </tr>
                            <tr >
                                <td class="td-max">Modul English</td>
                                <td class="td-max"><?php echo e($siswa->latestmodul('english')->nama ?? '--'); ?></td>
                            </tr>
                            <tr >
                                <td class="td-max">Iqro</td>
                                <td class="td-max"><?php echo e($siswa->latestmodul('iqro')->nama ?? '--'); ?></td>
                            </tr>
                            <tr >
                                <td class="td-max">Modul Lainnya</td>
                                <td class="td-max"><?php echo e($siswa->latestmodul('lain')->nama ?? '--'); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\M. Rivaldi Anwar Putra\Work\bimbel\resources\views/siswa/show.blade.php ENDPATH**/ ?>