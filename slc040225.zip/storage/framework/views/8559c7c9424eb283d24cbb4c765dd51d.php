<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
    <thead>
        <tr>
            <th>NIM</th>
            <th>Nama</th>
            <th>Kelas</th>
            <th>Guru/Admin</th>
        
            <th>Tgl Masuk</th>
            <th class="td-min">Lvl</th>

                <th>Status</th>
                <th>Keterangan</th>

            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->nim); ?></td>
                <td><a href="<?php echo e(route('siswa.show', $item->id)); ?>"><?php echo e($item->nama); ?></a></td>
                <td><?php echo e($item->kelas->nama); ?></td>
                <td>
                    <span class="<?php echo e(optional($item->kelas->guru)->status === 'non-aktif' ? 'text-danger' : ''); ?>">
                        <?php echo e(optional($item->kelas->guru)->name ?? '--'); ?>

                    </span> / 
                    <span class="<?php echo e(optional($item->kelas->user)->status === 'non-aktif' ? 'text-danger' : ''); ?>">
                        <?php echo e(optional($item->kelas->user)->name ?? '--'); ?>

                    </span>
                </td>
                
          
                <td><?php echo e(formattedDate($item->tanggal_masuk)); ?></td>
                <td>
             
                    <span><?php echo e($item->level ?? 'N/A'); ?></span>
         
                </td>
            
                <td>
                 
           
             
                    <span><?php echo e(ucwords($item->status)); ?></span>
           

                </td>
                <td>
  
                    <span><?php echo e($item->keterangan); ?></span>
         
                </td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table><?php /**PATH /var/www/vhosts/exakarya.com/bimbel.exakarya.com/resources/views/exports/siswa.blade.php ENDPATH**/ ?>