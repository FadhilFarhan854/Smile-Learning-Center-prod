<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use App\Models\Absen;
use App\Models\AbsenNotes;
use App\Exports\AbsenExport;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;

class AbsenController extends Controller
{
    /**
    * Display a listing of the resource.
    */
    public function index(Request $request)
    {
        $months = array(
            '1' => 'Jan',
            '2' => 'Feb',
            '3' => 'Mar',
            '4' => 'Apr',
            '5' => 'May',
            '6' => 'Jun',
            '7' => 'Jul',
            '8' => 'Aug',
            '9' => 'Sep',
            '10' => 'Oct',
            '11' => 'Nov',
            '12' => 'Dec',
        );
        
        
        $year = isset($request->tahun) ? $request->tahun : Carbon::now()->format('Y');
        $month = isset($request->month) ? $request->month : Carbon::now()->format('m');
        $filterDate = Carbon::createFromDate($year, $month+1, 1);
        $basicDate = Carbon::createFromDate($year, $month, 1);
        
        $daysInMonth = Carbon::create($year, $month, 1)->daysInMonth;
        
        $weekMap = [
            0 => 'Min',
            1 => 'Sen',
            2 => 'Sel',
            3 => 'Rab',
            4 => 'Kam',
            5 => 'Jum',
            6 => 'Sab',
        ];
        
        $reqUnit = $request->unit;
        $reqKelas = $request->kelas;
        
        $unit = auth()->user()->unitView();
        
        
        
        
        
        
        $siswaQuery = auth()->user()->siswaView()->filter(function ($item) use ($filterDate, $year, $month) {
            $tanggalMasuk = Carbon::parse($item->tanggal_masuk);
            $tanggalKeluar = $item->tanggal_lulus != null ? Carbon::parse($item->tanggal_lulus)->addMonths('1') : Carbon::createFromDate($year+100, $month+1, 1);
            
            return $tanggalMasuk->lte($filterDate) && $tanggalKeluar->gte($filterDate);
        });
        
        if (isset($request->unit) && $request->unit != 'all') {
            $kelas = auth()->user()->kelasView()->where('unit_id', $request->unit);

            $siswaQuery = $siswaQuery->filter(function ($siswaItem) use ($kelas) {
                return $kelas->pluck('id')->contains($siswaItem->kelas_id);
            });
        } else {
            $kelas = auth()->user()->kelasView();
        }

        if (isset($request->kelas) && $request->kelas != 'all') {
            $siswaQuery = $siswaQuery->where('kelas_id', $request->kelas);
        } 

        if ($request->has('search')) {
            $searchTerm = $request->search;
        
            $siswaQuery = $siswaQuery->filter(function ($item) use ($searchTerm) {
            // Perform case-insensitive search on 'nama' attribute
            return stripos($item->nama, $searchTerm) !== false;
        });
    }
		
		$siswa = $siswaQuery->paginate(15)->appends($request->except('page'));
        $dateToFill = [];
        
        foreach ($siswa as $key => $value) {
            $itemDate = Carbon::parse($value->tanggal_masuk);
            
            if ($value->tanggal_lulus) {
                $lulusDate = Carbon::parse($value->tanggal_lulus);
            } else {
                $lulusDate = null;
            }
            
            if ($itemDate->isSameMonth($basicDate) && $itemDate->isSameYear($basicDate)) {
                // Mark days before joining as 'PRE'
                for ($day = 1; $day < $itemDate->day; $day++) {
                    $dateToFill[$value->id][$day]['status'] = 'PRE';
					$dateToFill[$value->id][$day]['pertemuan'] = null;
                }
            } elseif ($lulusDate != null && $lulusDate->isSameMonth($basicDate) && $lulusDate->isSameYear($basicDate)) {
                // Mark days after graduating as 'POST'
                for ($day = $lulusDate->day + 1; $day <= $basicDate->endOfMonth()->day; $day++) {
                    $dateToFill[$value->id][$day]['status'] = 'POST';
					$dateToFill[$value->id][$day]['pertemuan'] = null;
                }
            }
            
            for ($day = 1; $day <= $basicDate->endOfMonth()->day; $day++) {
                if (!isset($dateToFill[$value->id][$day])) {
                    $dateToFill[$value->id][$day]['status'] = 'EMPTY';
					$dateToFill[$value->id][$day]['pertemuan'] = null;
                }
                $absen_date = Carbon::createFromDate($year, $month, $day)->format('Y-m-d');
                //dd($value->id);
                $status_absen = Absen::where('tanggal_absen', $absen_date)->where('siswa_id', $value->id)->first();
                //dd($status_absen);
                if (isset($status_absen)) {
                    $dateToFill[$value->id][$day]['status'] = $status_absen->status;
					$dateToFill[$value->id][$day]['pertemuan'] = $status_absen->pertemuan;
                }
            }
        }
        
        
        //dd($dateToFill);
        return view('absen.index', compact('months', 'year', 'month', 'daysInMonth', 'weekMap', 'siswa', 'dateToFill', 'kelas', 'unit', 'reqUnit', 'reqKelas'));
    }
    
    /**
    * Show the form for creating a new resource.
    */
    public function create()
    {
        //
    }
    
    /**
    * Store a newly created resource in storage.
    */
    public function store(Request $request)
    {
        //dd($request->all());
        
        $tanggal = Carbon::createFromDate($request->year, $request->month, $request->date)->format('Y-m-d');
        
        $existingRecord = Absen::where('siswa_id', $request->siswa_id)
        ->where('tanggal_absen', $tanggal)
        ->first();
        //dd($existingRecord);
        
        if ($existingRecord) {
            // Update the existing record with the new status
            $existingRecord->update(['status' => $request->status, 'pertemuan' => $request->pertemuan]);
        } else {
            // Create a new record if one doesn't exist
            $absen = Absen::create([
                'siswa_id' => $request->siswa_id,
                'tanggal_absen' => $tanggal,
                'status' => $request->status,
				'pertemuan' => $request->pertemuan
            ]);
        }
        
        return redirect()->back();
    }
    
    /**
    * Display the specified resource.
    */
    public function show(string $id)
    {
        //
    }
    
    /**
    * Show the form for editing the specified resource.
    */
    public function edit(string $id)
    {
        //
    }
    
    /**
    * Update the specified resource in storage.
    */
    public function update(Request $request, string $id)
    {
        //
    }
    
    /**
    * Remove the specified resource from storage.
    */
    public function destroy(string $id)
    {
        //
    }

    public function inputNote(Request $request)
    {
        $note = AbsenNotes::updateOrCreate(
            ['siswa_id' => $request->siswa_id, 'bulan' => $request->month, 'tahun' => $request->year],
            ['keterangan' => $request->keterangan]
        );

        
        return redirect('absen')->with('status', 'Input Note Berhasil');
    }

    public function deleteNote(Request $request)
    {
        AbsenNotes::destroy($request->id);

        
        return redirect('absen')->with('status', 'Hapus Note Berhasil');
    }

    public function exportAbsen($month, $year) 
    {
        return Excel::download(new AbsenExport($month, $year), 'Data Absen.xlsx');
    }
}
